import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: 'class',
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f9ff',
          100: '#e0f2fe',
          200: '#bae6fd',
          300: '#7dd3fc',
          400: '#38bdf8',
          500: '#0ea5e9',
          600: '#0284c7',
          700: '#0369a1',
          800: '#075985',
          900: '#0c4a6e',
        },
      },
      typography: {
        DEFAULT: {
          css: {
            maxWidth: '100ch',
            color: 'rgb(55 65 81)',
            '[class~="lead"]': {
              color: 'rgb(75 85 99)',
            },
            a: {
              color: '#0284c7',
              textDecoration: 'underline',
              fontWeight: '500',
            },
            strong: {
              color: 'rgb(31 41 55)',
              fontWeight: '600',
            },
            'ol[type="A"]': {
              '--list-counter-style': 'upper-alpha',
            },
            'ol[type="a"]': {
              '--list-counter-style': 'lower-alpha',
            },
            'ol[type="A" s]': {
              '--list-counter-style': 'upper-alpha',
            },
            'ol[type="a" s]': {
              '--list-counter-style': 'lower-alpha',
            },
            'ol[type="I"]': {
              '--list-counter-style': 'upper-roman',
            },
            'ol[type="i"]': {
              '--list-counter-style': 'lower-roman',
            },
            'ol[type="I" s]': {
              '--list-counter-style': 'upper-roman',
            },
            'ol[type="i" s]': {
              '--list-counter-style': 'lower-roman',
            },
            'ol[type="1"]': {
              '--list-counter-style': 'decimal',
            },
            'ol > li': {
              position: 'relative',
            },
            'ul > li': {
              position: 'relative',
            },
            kbd: {
              backgroundColor: 'rgb(243 244 246)',
              padding: '0.1em 0.4em',
              borderRadius: '0.25rem',
              fontSize: '0.875em',
              fontWeight: '600',
            },
          },
        },
        dark: {
          css: {
            color: 'rgb(209 213 219)',
            '[class~="lead"]': {
              color: 'rgb(156 163 175)',
            },
            a: {
              color: '#38bdf8',
            },
            strong: {
              color: 'rgb(229 231 235)',
            },
            kbd: {
              backgroundColor: 'rgb(31 41 55)',
            },
          },
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
  ],
};

export default config;
