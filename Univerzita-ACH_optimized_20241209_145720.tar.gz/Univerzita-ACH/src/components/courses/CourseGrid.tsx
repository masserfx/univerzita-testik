import React from 'react';
import Link from 'next/link';
import { Course } from '@/data/types';
import { Sun, Wind, Zap, Building, Users, Wrench, FileText, CheckCircle } from 'lucide-react';

interface CourseGridProps {
  courses: Course[];
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case 'Prodej Tepla':
      return Sun;
    case 'Fotovoltaika':
      return Zap;
    case 'Technologie':
      return Wrench;
    case 'Dokumentace':
      return FileText;
    case 'SVJ/BD':
      return Users;
    case 'Developer':
      return Building;
    default:
      return CheckCircle;
  }
};

const CourseGrid: React.FC<CourseGridProps> = ({ courses }) => {
  const categories = {
    'Prodej Tepla': courses.filter(c => 
      c.title.toLowerCase().includes('tepla') || 
      c.title.toLowerCase().includes('developer')),
    'Fotovoltaika': courses.filter(c => 
      c.title.toLowerCase().includes('fve') || 
      c.title.toLowerCase().includes('fotovoltai')),
    'Technologie': courses.filter(c => 
      c.title.toLowerCase().includes('technologie') || 
      c.title.toLowerCase().includes('portfolio')),
    'Obecné': courses.filter(c => 
      c.title.toLowerCase().includes('přehled') || 
      c.title.toLowerCase().includes('mapa') ||
      c.title.toLowerCase().includes('úvod'))
  };

  return (
    <div className="p-6 bg-content1 dark:bg-content2 rounded-xl shadow-lg border border-default-200 dark:border-default-100">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {Object.entries(categories).map(([category, categoryCourses]) => (
          <div key={category} className="bg-background dark:bg-content3 rounded-lg p-4 shadow-md">
            <div className="flex items-center mb-4">
              {React.createElement(getCategoryIcon(category), {
                className: "w-6 h-6 mr-2 text-primary dark:text-primary"
              })}
              <h2 className="text-xl font-bold text-default-900 dark:text-default-100">{category}</h2>
            </div>
            <div className="space-y-4">
              {categoryCourses.map((course) => (
                <Link 
                  key={course.id} 
                  href={`/kurzy/${course.id}`}
                  className="block p-4 bg-content1 dark:bg-content2 rounded-md hover:bg-content2 dark:hover:bg-content4 transition-colors border border-default-200 dark:border-default-100"
                >
                  <h3 className="font-medium mb-2 text-default-800 dark:text-default-200">{course.title}</h3>
                  <p className="text-sm text-default-600 dark:text-default-400 line-clamp-2">
                    {course.description}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseGrid; 