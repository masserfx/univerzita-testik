'use client';

import React, { useCallback, useState } from 'react';
import { useRouter } from 'next/navigation';
import ReactFlow, {
  Node,
  Edge,
  Background,
  Controls,
  NodeTypes,
  NodeProps,
  Handle,
  Position,
  OnNodesChange,
  applyNodeChanges,
  MarkerType,
} from 'reactflow';
import 'reactflow/dist/style.css';

interface CourseLink {
  id: string;
  title: string;
  node: string;
}

const courseLinks: CourseLink[] = [
  { id: 'proces-prodej-tepla', title: 'Prodej tepla SVJ/BD', node: 'SVJ/BD' },
  { id: 'proces-prodej-tepla-developer', title: 'Prodej tepla developer', node: 'Developer' },
  { id: 'proces-prodej-technologie', title: 'Prodej technologie', node: 'Prodej Technologie' },
  { id: 'proces-prodej-fve-samostatne', title: 'Samostatná FVE', node: 'Samostatná FVE' },
  { id: 'proces-prodej-fve-v-soubehu-s-tc', title: 'FVE s tepelným čerpadlem', node: 'FVE s TČ' },
  { id: 'produktove-portfolio-bd', title: 'Produktové portfolio', node: 'Prodej Technologie' },
  { id: 'prehled-pro-obchodnika-bd', title: 'Přehled pro obchodníka', node: 'Obchodní proces' }
];

const CustomNode = ({ data }: NodeProps) => {
  const router = useRouter();
  const isClickable = courseLinks.some(link => link.node === data.label);
  
  const handleClick = () => {
    if (isClickable) {
      const courseLink = courseLinks.find(link => link.node === data.label);
      if (courseLink) {
        router.push(`/kurzy/${courseLink.id}`);
      }
    }
  };

  return (
    <div
      className={`px-3 py-2 shadow-lg rounded-lg transition-all duration-200 ${
        data.isRoot ? 'bg-primary-600 text-white border-2 border-primary-700' :
        data.isMain ? 'bg-primary-500 text-white border border-primary-600' :
        'bg-white text-primary-700 border border-primary-300 hover:border-primary-500 hover:shadow-xl'
      } ${
        isClickable ? 'cursor-pointer' : ''
      }`}
      style={{
        minWidth: '130px',
        maxWidth: '160px',
        textAlign: 'center',
        fontSize: '0.9rem',
        boxShadow: data.isRoot ? '0 0 0 2px white, 0 0 0 4px var(--nextui-colors-primary)' : undefined,
      }}
      onClick={handleClick}
    >
      <Handle type="target" position={Position.Top} className="!bg-primary" />
      <span className="font-medium">{data.label}</span>
      <Handle type="source" position={Position.Bottom} className="!bg-primary" />
    </div>
  );
};

const nodeTypes: NodeTypes = {
  custom: CustomNode,
};

const InteractiveMindMap: React.FC = () => {
  const [nodes, setNodes] = useState<Node[]>([
    // Root
    { id: 'root', type: 'custom', position: { x: 600, y: 0 }, data: { label: 'Energetická Řešení', isRoot: true }, draggable: false },
    
    // Main categories
    { id: 'teplo', type: 'custom', position: { x: 200, y: 150 }, data: { label: 'Prodej Tepla', isMain: true } },
    { id: 'fve', type: 'custom', position: { x: 600, y: 150 }, data: { label: 'Fotovoltaika', isMain: true } },
    { id: 'tech', type: 'custom', position: { x: 1000, y: 150 }, data: { label: 'Prodej Technologie', isMain: true } },
    
    // Prodej Tepla subcategories
    { id: 'dev', type: 'custom', position: { x: 100, y: 300 }, data: { label: 'Developer' } },
    { id: 'svj', type: 'custom', position: { x: 300, y: 300 }, data: { label: 'SVJ/BD' } },
    
    // Fotovoltaika subcategories
    { id: 'fve1', type: 'custom', position: { x: 500, y: 300 }, data: { label: 'Samostatná FVE' } },
    { id: 'fve2', type: 'custom', position: { x: 700, y: 300 }, data: { label: 'FVE s TČ' } },
    
    // Prodej Technologie subcategories
    { id: 'tech1', type: 'custom', position: { x: 900, y: 300 }, data: { label: 'Obchodní proces' } },
    { id: 'tech2', type: 'custom', position: { x: 1100, y: 300 }, data: { label: 'Realizace' } },
  ]);

  const [edges, setEdges] = useState<Edge[]>([
    // Root connections
    { id: 'root-teplo', source: 'root', target: 'teplo' },
    { id: 'root-fve', source: 'root', target: 'fve' },
    { id: 'root-tech', source: 'root', target: 'tech' },
    
    // Prodej Tepla connections
    { id: 'teplo-dev', source: 'teplo', target: 'dev' },
    { id: 'teplo-svj', source: 'teplo', target: 'svj' },
    
    // Fotovoltaika connections
    { id: 'fve-fve1', source: 'fve', target: 'fve1' },
    { id: 'fve-fve2', source: 'fve', target: 'fve2' },
    
    // Prodej Technologie connections
    { id: 'tech-tech1', source: 'tech', target: 'tech1' },
    { id: 'tech-tech2', source: 'tech', target: 'tech2' },
  ]);

  const onNodesChange: OnNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );

  const router = useRouter();

  return (
    <div className="p-6 bg-content1 dark:bg-content2 rounded-xl shadow-lg border border-default-200 dark:border-default-100">
      <div className="h-[600px] w-full">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          onNodesChange={onNodesChange}
          fitView
          className="bg-background dark:bg-background"
          minZoom={0.4}
          maxZoom={1.5}
          defaultEdgeOptions={{
            type: 'smoothstep',
            style: { strokeWidth: 2 },
            markerEnd: { type: MarkerType.ArrowClosed },
          }}
          fitViewOptions={{
            padding: 0.2,
            minZoom: 0.4,
            maxZoom: 1,
          }}
        >
          <Background />
          <Controls />
        </ReactFlow>
      </div>
      <div className="mt-4 space-y-2">
        <p className="text-sm text-default-600 dark:text-default-400">
          Kliknutím na zvýrazněné položky v mapě přejdete na související kurz. Pro lepší přehled můžete mapu přiblížit/oddálit a přesouvat uzly.
        </p>
        <ul className="text-sm space-y-1">
          {courseLinks.map(link => (
            <li key={link.id} className="text-primary hover:underline cursor-pointer"
                onClick={() => router.push(`/kurzy/${link.id}`)}>
              {link.title} ({link.node})
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default InteractiveMindMap; 