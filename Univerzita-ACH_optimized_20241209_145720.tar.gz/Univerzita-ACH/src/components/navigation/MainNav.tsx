'use client';

import {
  Navbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  Link,
} from "@nextui-org/react";
import Image from 'next/image';
import { ThemeToggle } from '../ui/ThemeToggle';
import NextLink from 'next/link';
import { Button } from "@/components/ui/button";

export function MainNav() {
  return (
    <Navbar 
      maxWidth="2xl" 
      position="sticky"
      className="bg-content1/80 dark:bg-content1/80 backdrop-blur-lg border-b border-default-200 dark:border-default-100"
      classNames={{
        wrapper: "px-4 sm:px-6 lg:px-8 h-14",
        item: "data-[active=true]:text-primary"
      }}
    >
      <NavbarBrand>
        <NextLink href="/" passHref>
          <Image
            src="/images/ac-heating-logo.png"
            alt="AC Heating Logo"
            width={120}
            height={32}
            className="h-8 w-auto dark:brightness-0 dark:invert"
            priority
          />
        </NextLink>
      </NavbarBrand>

      <NavbarContent className="hidden sm:flex gap-6" justify="center">
        <NavbarItem>
          <Link 
            as={NextLink}
            href="/kurzy/myslenkova-mapa-obchodni-proces"
            className="text-default-600 hover:text-primary dark:text-default-400 dark:hover:text-primary transition-colors"
          >
            Mapa Procesů
          </Link>
        </NavbarItem>
        <NavbarItem>
          <Link 
            as={NextLink}
            href="/kurzy"
            className="text-default-600 hover:text-primary dark:text-default-400 dark:hover:text-primary transition-colors"
          >
            Mapa Kurzů
          </Link>
        </NavbarItem>
        <NavbarItem>
          <Link 
            as={NextLink}
            href="/dokumenty"
            className="text-default-600 hover:text-primary dark:text-default-400 dark:hover:text-primary transition-colors"
          >
            Dokumenty
          </Link>
        </NavbarItem>
        <NavbarItem>
          <Link 
            as={NextLink}
            href="/testy"
            className="text-default-600 hover:text-primary dark:text-default-400 dark:hover:text-primary transition-colors"
          >
            Testy
          </Link>
        </NavbarItem>
      </NavbarContent>

      <NavbarContent justify="end">
        <NavbarItem>
          <ThemeToggle />
        </NavbarItem>
      </NavbarContent>
    </Navbar>
  );
} 