import React from 'react';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';

interface MarkdownProps {
  children: string;
}

export const Markdown: React.FC<MarkdownProps> = ({ children }) => {
  return (
    <ReactMarkdown
      rehypePlugins={[rehypeRaw]}
      components={{
        h1: ({ node, ...props }) => <h1 className="text-3xl font-bold mb-6 text-default-900 dark:text-default-100" {...props} />,
        h2: ({ node, ...props }) => <h2 className="text-2xl font-bold mt-8 mb-4 text-default-800 dark:text-default-200" {...props} />,
        h3: ({ node, ...props }) => <h3 className="text-xl font-semibold mt-6 mb-3 text-default-700 dark:text-default-300" {...props} />,
        h4: ({ node, ...props }) => <h4 className="text-lg font-semibold mt-4 mb-2 text-default-600 dark:text-default-400" {...props} />,
        p: ({ node, ...props }) => <p className="mb-4 text-default-600 dark:text-default-400 leading-relaxed" {...props} />,
        ul: ({ node, ...props }) => <ul className="list-disc list-inside mb-4 space-y-2" {...props} />,
        ol: ({ node, ...props }) => <ol className="list-decimal list-inside mb-4 space-y-2" {...props} />,
        li: ({ node, ...props }) => <li className="text-default-600 dark:text-default-400" {...props} />,
        a: ({ node, ...props }) => (
          <a
            className="text-primary hover:underline"
            target={props.href?.startsWith('http') ? '_blank' : undefined}
            rel={props.href?.startsWith('http') ? 'noopener noreferrer' : undefined}
            {...props}
          />
        ),
        blockquote: ({ node, ...props }) => (
          <blockquote className="border-l-4 border-primary pl-4 my-4 italic text-default-500 dark:text-default-400" {...props} />
        ),
        code: ({ inline, className, children, ...props }: any) =>
          inline ? (
            <code className="px-1.5 py-0.5 bg-content2 dark:bg-content3 rounded text-sm" {...props}>
              {children}
            </code>
          ) : (
            <code className="block bg-content2 dark:bg-content3 p-4 rounded-lg overflow-x-auto text-sm" {...props} />
          ),
        img: ({ node, ...props }) => (
          <img
            className="rounded-lg shadow-lg max-w-full h-auto my-4"
            loading="lazy"
            {...props}
            alt={props.alt || ''}
          />
        ),
        table: ({ node, ...props }) => (
          <div className="overflow-x-auto my-4">
            <table className="min-w-full divide-y divide-default-200 dark:divide-default-700" {...props} />
          </div>
        ),
        th: ({ node, ...props }) => (
          <th className="px-4 py-3 bg-content2 dark:bg-content3 text-left text-default-700 dark:text-default-300 font-semibold" {...props} />
        ),
        td: ({ node, ...props }) => (
          <td className="px-4 py-3 text-default-600 dark:text-default-400 border-t border-default-200 dark:border-default-700" {...props} />
        ),
      }}
    >
      {children}
    </ReactMarkdown>
  );
}; 