'use client';

import React from 'react';
import InteractiveMindMap from '@/components/courses/InteractiveMindMap';

export default function ProcessMapPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-8 text-center">Mapa Procesů AC Heating</h1>
      <InteractiveMindMap />
    </div>
  );
} 