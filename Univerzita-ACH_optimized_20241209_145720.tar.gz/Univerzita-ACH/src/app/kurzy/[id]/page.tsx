'use client';

import { useEffect, useState } from 'react';
import { notFound } from 'next/navigation';
import { courses } from '@/data/courses';
import { Course } from '@/data/types';
import { Markdown } from '@/components/ui/markdown';
import dynamic from 'next/dynamic';

const InteractiveMindMap = dynamic(
  () => import('@/components/courses/InteractiveMindMap'),
  { ssr: false }
);

export default function CoursePage({ params }: { params: { id: string } }) {
  const [course, setCourse] = useState<Course | null>(null);

  useEffect(() => {
    const foundCourse = courses.find((c) => c.id === params.id);
    if (!foundCourse) {
      notFound();
    }
    setCourse(foundCourse);
  }, [params.id]);

  if (!course) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const processContent = (content: string) => {
    if (content.includes('<InteractiveMindMap />')) {
      const parts = content.split('<InteractiveMindMap />');
      return (
        <>
          <Markdown>{parts[0]}</Markdown>
          <div className="my-8">
            <InteractiveMindMap />
          </div>
          {parts[1] && <Markdown>{parts[1]}</Markdown>}
        </>
      );
    }
    return <Markdown>{content}</Markdown>;
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              course.level === 'beginner' 
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' 
                : course.level === 'intermediate'
                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
            }`}>
              {course.level === 'beginner' ? 'Základní' :
               course.level === 'intermediate' ? 'Pokročilý' :
               'Expert'}
            </span>
            <span className="text-sm text-default-500">{course.duration}</span>
          </div>
          <h1 className="text-4xl font-bold mb-4 text-default-900 dark:text-default-100">{course.title}</h1>
          <p className="text-xl text-default-700 dark:text-default-300 mb-4">{course.description}</p>
          <div className="flex flex-wrap gap-2">
            {course.tags?.map((tag) => (
              <span
                key={tag}
                className="px-2 py-1 bg-content2 dark:bg-content3 text-default-700 dark:text-default-300 rounded-full text-sm"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          {course.modules.map((module) => (
            <div key={module.id} className="bg-content1 dark:bg-content2 rounded-lg p-6 shadow-lg">
              <h2 className="text-2xl font-bold mb-4 text-default-900 dark:text-default-100">
                {module.title}
              </h2>
              <div className="prose dark:prose-invert max-w-none">
                {processContent(module.content)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
} 