'use client';

import React from 'react';
import { courses } from '@/data/courses/index';
import CourseGrid from '@/components/courses/CourseGrid';
import InteractiveMindMap from '@/components/courses/InteractiveMindMap';

export default function CoursesPage() {
  return (
    <div className="container mx-auto py-6 space-y-8">
      <CourseGrid courses={courses} />
    </div>
  );
} 