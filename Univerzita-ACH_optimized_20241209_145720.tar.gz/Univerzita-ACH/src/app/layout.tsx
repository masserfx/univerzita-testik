import { Providers } from './providers';
import './globals.css';
import { Inter } from 'next/font/google';
import { MainNav } from '@/components/navigation/MainNav';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'AC Heating Univerzita',
  description: 'Vzdělávací platforma pro AC Heating',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="cs" suppressHydrationWarning>
      <body className={inter.className}>
        <Providers>
          <div className="relative min-h-screen bg-background font-sans antialiased">
            <MainNav />
            <main className="container mx-auto max-w-7xl pt-16 px-6 flex-grow">
              {children}
            </main>
            <footer className="w-full flex items-center justify-center py-3">
              <span className="text-default-600">© {new Date().getFullYear()} AC Heating</span>
            </footer>
          </div>
        </Providers>
      </body>
    </html>
  );
}
