export const acHeatingIntro = {
  id: 'ac-heating-intro',
  title: 'Úvod do AC Heating',
  description: 'Základní kurz o společnosti AC Heating, jejích produktech a službách',
  duration: '120'
};