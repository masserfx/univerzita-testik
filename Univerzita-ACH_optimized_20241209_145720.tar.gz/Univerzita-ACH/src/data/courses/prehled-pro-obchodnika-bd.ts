import { Course } from '../types';

export const prehledProObchodnikaBDCourse: Course = {
  id: 'prehled-pro-obchodnika-bd',
  title: 'Komplexní vzdělávací program pro obchodníky energetických řešení',
  description: 'Komplexní průvodce pro obchodníky, zahrnující produktové portfolio, specifika prodeje, prodejní proces a praktické návody.',
  duration: '60 minut',
  level: 'intermediate',
  tags: ['obchod', 'prodej', 'energie', 'vzdělávání', 'portfolio'],
  modules: [
    {
      id: 'produktove-portfolio',
      title: 'Základní přehled produktového portfolia',
      type: 'lesson',
      content: `# Základní přehled produktového portfolia

### Hlavní produktové linie
- Prodej tepla pro developery
- Prodej tepla pro SVJ/BD
- Prodej technologie
- Fotovoltaické elektrárny
  - V souběhu s tepelným čerpadlem
  - Samostatné instalace

### Klíčové výhody jednotlivých řešení
- **Prodej tepla**
  - Minimální vstupní investice pro zákazníka
  - Profesionální správa a údržba
  - Garantované dodávky tepla
- **Prodej technologie**
  - Plná kontrola nad zařízením
  - Možnost využití dotací
  - Vlastní správa systému
- **Fotovoltaické elektrárny**
  - Snížení energetické závislosti
  - Ekologický zdroj energie
  - Kombinace s tepelným čerpadlem pro maximální efektivitu`
    },
    {
      id: 'specifika-prodeje',
      title: 'Specifika jednotlivých typů prodeje',
      type: 'lesson',
      content: `# Specifika jednotlivých typů prodeje

### Prodej tepla pro developery
**Klíčové body:**
- Dlouhodobá spolupráce
- Technická součinnost při projekčních pracích
- Nutnost řešení věcných břemen a souvisejících smluv
- Důraz na včasnou koordinaci s výstavbou

**Potřebné dokumenty:**
- Smlouva o spolupráci
- Smlouva o zřízení služebnosti
- Smlouva o výhradě odděleného vlastnictví

### Prodej tepla pro SVJ/BD
**Klíčové body:**
- Nutnost schválení shromážděním vlastníků
- Důležitost ekonomické rozvahy
- Řešení odpojení od CZT
- Příprava nájemní smlouvy

**Proces schvalování:**
1. První kontakt a prezentace řešení
2. Jednání s výborem
3. Příprava podkladů pro shromáždění
4. Schválení na shromáždění vlastníků

### Prodej technologie
**Klíčové body:**
- Komplexní technické řešení
- Nutnost stavebního povolení
- Koordinace s dotačními programy
- Důraz na kvalitu projektové dokumentace

**Fáze prodeje:**
1. Úvodní analýza potřeb
2. Technické zaměření
3. Zpracování projektové dokumentace
4. Realizace a předání`
    },
    {
      id: 'prodejni-proces',
      title: 'Prodejní proces krok za krokem',
      type: 'lesson',
      content: `# Prodejní proces krok za krokem

### První kontakt se zákazníkem
- Identifikace typu zákazníka
- Základní analýza potřeb
- Představení vhodného řešení
- Sběr vstupních dat

### Příprava nabídky
- Technické posouzení
- Ekonomická rozvaha
- Návrh financování
- Prezentace řešení

### Jednání a uzavření obchodu
- Řešení námitek
- Příprava smluvní dokumentace
- Koordinace s technickým oddělením
- Finalizace obchodu`
    },
    {
      id: 'prakticke-navody',
      title: 'Praktické návody a postupy',
      type: 'lesson',
      content: `# Praktické návody a postupy

### Příprava na jednání
**Checklist před jednáním:**
- Analýza lokality a současného stavu
- Příprava referenčních projektů
- Ekonomická rozvaha
- Technické podklady

### Vedení obchodního jednání
**Klíčové body jednání:**
- Představení společnosti a řešení
- Zjištění potřeb a motivace
- Prezentace výhod
- Řešení námitek

### Follow-up a další kroky
- Zápis z jednání
- Stanovení dalších kroků
- Koordinace s ostatními odděleními
- Časový harmonogram`
    },
    {
      id: 'kontrolni-seznamy',
      title: 'Kontrolní seznamy pro obchodníky',
      type: 'lesson',
      content: `# Kontrolní seznamy pro obchodníky

### Dokumenty potřebné pro jednotlivé typy prodejů
**Developer:**
- [ ] Smlouva o spolupráci
- [ ] Smlouva o zřízení služebnosti
- [ ] Projektová dokumentace
- [ ] Stavební povolení

**SVJ/BD:**
- [ ] Nájemní smlouva
- [ ] Ekonomická rozvaha
- [ ] Podklady pro shromáždění
- [ ] Technická specifikace

**Technologie:**
- [ ] Technická dokumentace
- [ ] Projektová dokumentace
- [ ] Stavební povolení
- [ ] Dotační podklady

### Časová osa projektu
**Přípravná fáze:**
- Identifikace zákazníka
- První kontakt
- Analýza potřeb
- Příprava nabídky

**Realizační fáze:**
- Technické zaměření
- Projektová dokumentace
- Stavební řízení
- Realizace

**Dokončovací fáze:**
- Předání díla
- Dokumentace
- Zaškolení
- Servisní smlouva`
    },
    {
      id: 'zaver-doporuceni',
      title: 'Závěr a doporučení pro praxi',
      type: 'lesson',
      content: `# Závěr a doporučení pro praxi

### Klíčové faktory úspěchu:
1. Důkladná příprava na jednání
2. Znalost technických specifik
3. Schopnost vysv��tlit výhody řešení
4. Profesionální přístup k dokumentaci
5. Efektivní komunikace s ostatními odděleními

### Doporučení pro další rozvoj:
- Pravidelné sledování novinek v oboru
- Sdílení zkušeností s kolegy
- Zpětná vazba od zákazníků
- Kontinuální vzdělávání`
    }
  ]
}; 