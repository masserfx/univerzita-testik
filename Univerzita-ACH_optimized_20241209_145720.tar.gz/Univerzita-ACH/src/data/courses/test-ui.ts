import { Course } from '../types';

export const testUiCourse: Course = {
  id: 'test-ui',
  title: 'Testovací kurz pro UI',
  description: 'Tento kurz slouží k testování různých komponent a dark/light módu',
  duration: '45 minut',
  level: 'beginner',
  tags: ['UI', 'test', 'komponenty'],
  modules: [
    {
      id: 'uvod',
      title: 'Úvodní modul',
      type: 'lesson',
      content: `# Úvodní modul

## Testování nadpisů a textu

Tento text slouží k testování základní typografie a kontrastu v různých režimech zobrazení.

### Odrážkový seznam
- První položka s **tučným** textem
- Druhá položka s *kurzívou*
- Třetí položka s [odkazem](#)

### Číslovaný seznam
1. První krok procesu
2. Druhý krok s \`kódem\`
3. Třetí krok s poznámkou

## Testování obrázků a popisků

<div class="my-4">
  <img src="/images/test/test-image-1.jpg" alt="Testovací obrázek" class="rounded-lg shadow-lg" />
  <p class="text-sm text-default-500 mt-2 text-center italic">Popisek pod obrázkem pro testování kontrastu</p>
</div>

## Testování citací a boxů

> Toto je citace, která slouží k testování kontrastu a odsazení v různých režimech zobrazení.

<div class="bg-content2 p-4 rounded-lg my-4">
  <h4 class="font-semibold text-default-700 dark:text-default-400">Důležité upozornění</h4>
  <p class="text-default-600 dark:text-default-300">Tento box obsahuje důležité informace a testuje různé úrovně kontrastu.</p>
</div>`
    },
    {
      id: 'komponenty',
      title: 'Testování komponent',
      type: 'lesson',
      content: `# Testování komponent

## Tlačítka a interaktivní prvky

<div class="flex gap-4 my-4">
  <button class="bg-primary text-white px-4 py-2 rounded-lg hover:opacity-90">
    Primární tlačítko
  </button>
  <button class="bg-content2 text-default-700 dark:text-default-400 px-4 py-2 rounded-lg hover:opacity-90">
    Sekundární tlačítko
  </button>
</div>

## Karty a boxy

<div class="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
  <div class="bg-content1 p-4 rounded-lg shadow-sm">
    <h3 class="text-default-700 dark:text-default-400 font-semibold">První karta</h3>
    <p class="text-default-600 dark:text-default-300 mt-2">Obsah první karty pro testování kontrastu.</p>
  </div>
  <div class="bg-content2 p-4 rounded-lg shadow-sm">
    <h3 class="text-default-700 dark:text-default-400 font-semibold">Druhá karta</h3>
    <p class="text-default-600 dark:text-default-300 mt-2">Obsah druhé karty s jiným pozadím.</p>
  </div>
</div>

## Tabulky

<div class="overflow-x-auto my-4">
  <table class="w-full border-collapse">
    <thead class="bg-content2">
      <tr>
        <th class="p-2 text-left text-default-700 dark:text-default-400 border border-default-200">Sloupec 1</th>
        <th class="p-2 text-left text-default-700 dark:text-default-400 border border-default-200">Sloupec 2</th>
        <th class="p-2 text-left text-default-700 dark:text-default-400 border border-default-200">Sloupec 3</th>
      </tr>
    </thead>
    <tbody>
      <tr class="bg-content1">
        <td class="p-2 text-default-600 dark:text-default-300 border border-default-200">Buňka 1</td>
        <td class="p-2 text-default-600 dark:text-default-300 border border-default-200">Buňka 2</td>
        <td class="p-2 text-default-600 dark:text-default-300 border border-default-200">Buňka 3</td>
      </tr>
      <tr class="bg-content2">
        <td class="p-2 text-default-600 dark:text-default-300 border border-default-200">Buňka 4</td>
        <td class="p-2 text-default-600 dark:text-default-300 border border-default-200">Buňka 5</td>
        <td class="p-2 text-default-600 dark:text-default-300 border border-default-200">Buňka 6</td>
      </tr>
    </tbody>
  </table>
</div>`
    },
    {
      id: 'formulare',
      title: 'Testování formulářů',
      type: 'lesson',
      content: `# Testování formulářů

## Základní formulářové prvky

<div class="space-y-4 my-4">
  <div>
    <label class="block text-default-700 dark:text-default-400 mb-1">Textové pole</label>
    <input type="text" class="w-full p-2 rounded-lg bg-content1 border border-default-200 text-default-700 dark:text-default-300" placeholder="Zadejte text..." />
  </div>

  <div>
    <label class="block text-default-700 dark:text-default-400 mb-1">Výběr možností</label>
    <select class="w-full p-2 rounded-lg bg-content1 border border-default-200 text-default-700 dark:text-default-300">
      <option>Možnost 1</option>
      <option>Možnost 2</option>
      <option>Možnost 3</option>
    </select>
  </div>

  <div>
    <label class="block text-default-700 dark:text-default-400 mb-1">Textová oblast</label>
    <textarea class="w-full p-2 rounded-lg bg-content1 border border-default-200 text-default-700 dark:text-default-300" rows="4" placeholder="Zadejte delší text..."></textarea>
  </div>
</div>

## Zaškrtávací pole a přepínače

<div class="space-y-2 my-4">
  <div class="flex items-center">
    <input type="checkbox" class="mr-2" />
    <label class="text-default-700 dark:text-default-400">Zaškrtávací pole 1</label>
  </div>
  <div class="flex items-center">
    <input type="checkbox" class="mr-2" />
    <label class="text-default-700 dark:text-default-400">Zaškrtávací pole 2</label>
  </div>
  <div class="flex items-center">
    <input type="radio" name="radio" class="mr-2" />
    <label class="text-default-700 dark:text-default-400">Přepínač 1</label>
  </div>
  <div class="flex items-center">
    <input type="radio" name="radio" class="mr-2" />
    <label class="text-default-700 dark:text-default-400">Přepínač 2</label>
  </div>
</div>`
    }
  ]
}; 