import { Course } from '../types';

export const procesProdejTeplaDevCourse: Course = {
  id: 'proces-prodej-tepla-developer',
  title: 'Procesní mapa - Prodej tepla developer',
  description: 'Komplexní průvodce procesem prodeje tepla pro developerské projekty, od obchodní fáze až po dokončení a archivaci.',
  duration: '60 minut',
  level: 'intermediate',
  tags: ['procesy', 'developer', 'teplo', 'administrativa', 'realizace'],
  modules: [
    {
      id: 'obchodni-faze',
      title: 'Obchodní fáze',
      type: 'lesson',
      content: `# Obchodní fáze

### Obchodní jednání
**Zodpovídá:** Obchodník (O)
**Činnosti:**
- Identifikace developerského projektu
- Prezentace řešení
- Vyjednávání podmínek spolupráce
- Příprava obchodní nabídky
- Kalkulace nákladů a výnosů`
    },
    {
      id: 'technicka-priprava',
      title: 'Technická příprava',
      type: 'lesson',
      content: `# Technická příprava

### Technická součinnost
**Zodpovídá:** Technik (T)
**Činnosti:**
- Součinnost při projekčních pracích
- Konzultace technického řešení
- Optimalizace návrhu
- Koordinace s projektantem developera
- Příprava technických podkladů`
    },
    {
      id: 'smluvni-dokumentace',
      title: 'Smluvní dokumentace',
      type: 'lesson',
      content: `# Smluvní dokumentace

### Příprava a podpis smluv
**Zodpovídá:** Obchodník (O)
**Vyřizuje:** Obchodník (O) + Zákazník (Z)
**Dokumenty:**
1. Smlouva o spolupráci
2. Smlouva o zřízení služebnosti
3. Smlouva o výhradě odděleného vlastnictví
4. Smlouva o zřízení služebnosti pro zápis do KN

### Evidence a kontrola
**Zodpovídá:** Obchodník (O)
**Vyřizuje:** Back Office (BO)
**Činnosti:**
- Evidence podepsané smlouvy
- Kontrola platby rezervačního poplatku
- Předání dokumentace technikovi
- Zajištění komunikace s projektantem/developerem`
    },
    {
      id: 'stavebni-faze',
      title: 'Stavební fáze',
      type: 'lesson',
      content: `# Stavební fáze

### Příprava stavby
**Zodpovídá:** Zákazník (Z)
**Činnosti:**
- Změna stavby před dokončením
  - V případě absence TČ ve stavebním povolení
- Koordinace s hlavní stavbou

### Technická součinnost
**Zodpovídá:** Obchodník (O)
**Vyřizuje:** Technik (T)
**Činnosti:**
- Průběžná technická podpora
- Kontrola realizace
- Řešení technických detailů
- Koordinace s projektantem

### Realizační fáze
**Zodpovídá:** Zákazník (Z)
**Činnosti:**
- Hrubá stavba bez oken
- Kontrola připravenosti
- Koordinace návazných prací`
    },
    {
      id: 'pravni-nalezitosti',
      title: 'Právní náležitosti',
      type: 'lesson',
      content: `# Právní náležitosti

### Katastr nemovitostí
**Zodpovídá:** Obchodník (O)
**Vyřizuje:** Zákazník (Z)
**Činnosti:**
1. Zápis stavby do katastru nemovitostí
2. Zápis věcného břemene do katastru nemovitostí

### Evidence a kontrola zápisů
**Zodpovídá:** Obchodník (O)
**Vyřizuje:** Back Office (BO)
**Činnosti:**
- Evidence termínů zápisů do KN
- Kontrola provedení zápisů
- Archivace dokumentace`
    },
    {
      id: 'kontrolni-body',
      title: 'Kontrolní body procesu',
      type: 'lesson',
      content: `# Kontrolní body procesu

### Obchodní část
- [ ] Uzavření všech potřebných smluv
- [ ] Úhrada rezervačního poplatku
- [ ] Předání dokumentace technickému oddělení

### Technická část
- [ ] Schválení technického řešení
- [ ] Zapracování TČ do projektové dokumentace
- [ ] Kontrola připravenosti stavby

### Právní část
- [ ] Zápis stavby do KN
- [ ] Zápis věcného břemene
- [ ] Kontrola všech právních náležitostí`
    },
    {
      id: 'casova-osa',
      title: 'Časová osa projektu',
      type: 'lesson',
      content: `# Časová osa projektu

1. **Přípravná fáze**
   - Obchodní jednání
   - Technické konzultace
   - Příprava smluv

2. **Smluvní fáze**
   - Podpis smluv
   - Evidence dokumentace
   - Úhrada poplatků

3. **Realizační fáze**
   - Technická součinnost
   - Stavební práce
   - Kontrola připravenosti

4. **Dokončovací fáze**
   - Zápisy do KN
   - Evidence
   - Archivace`
    },
    {
      id: 'zodpovednosti',
      title: 'Zodpovědnosti jednotlivých oddělení',
      type: 'lesson',
      content: `# Zodpovědnosti jednotlivých oddělení

### Obchodní oddělení (O)
- Vedení obchodních jednání
- Příprava a uzavření smluv
- Koordinace procesu

### Technické oddělení (T)
- Technická součinnost
- Kontrola realizace
- Odborné konzultace

### Back Office (BO)
- Evidence dokumentů
- Kontrola plateb
- Správa termínů

### Zákazník (Z)
- Stavební připravenost
- Zápisy do KN
- Koordinace stavby`
    },
    {
      id: 'dokumentace',
      title: 'Dokumentace a archivace',
      type: 'lesson',
      content: `# Dokumentace a archivace

### Povinné dokumenty
1. Smluvní dokumentace
2. Technická dokumentace
3. Stavební dokumentace
4. Výpisy z KN

### Evidence
- Termíny zápisů
- Platby
- Technické specifikace
- Kontrolní protokoly`
    }
  ]
}; 