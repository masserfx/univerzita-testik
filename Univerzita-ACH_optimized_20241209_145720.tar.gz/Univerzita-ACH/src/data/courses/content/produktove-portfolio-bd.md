# PŘÍRUČKA PRO OBCHODNÍKY - PRODUKTOVÉ PORTFOLIO

## OBSAH
1. [Prodej tepla - Developer](#1-prodej-tepla---developer)
2. [Prodej tepla - SVJ/BD](#2-prodej-tepla---svjbd)
3. [Prodej technologie](#3-prodej-technologie)
4. [FVE - Souběh s tepelným čerpadlem](#4-fve---soubeh-s-tepelnym-cerpadlem)
5. [FVE - Samostatná instalace](#5-fve---samostatna-instalace)

## 1. PRODEJ TEPLA - DEVELOPER

### 1.1 Charakteristika produktu
- Komplexní řešení pro developery
- Dlouhodobé partnerství
- Minimální vstupní investice
- Profesionální správa systému

### 1.2 Procesní postup
1. **Obchodní jednání**
   - Představení společnosti
   - Analýza potřeb developera
   - Prezentace řešení
   - Předběžná kalkulace

2. **Technická součinnost**
   - Spolupráce při projekčních pracích
   - Konzultace technického řešení
   - Optimalizace návrhu

3. **Smluvní dokumentace**
   - Smlouva o spolupráci
   - Smlouva o zřízení služebnosti
   - Smlouva o výhradě odděleného vlastnictví
   - Smlouva o dodávce tepla

4. **Stavební fáze**
   - Koordinace s výstavbou
   - Technický dozor
   - Kontrola připravenosti

5. **Dokončení a předání**
   - Kolaudace
   - Předávací protokoly
   - Zahájení dodávek tepla

### 1.3 Potřebná dokumentace
- **Přípravná fáze**
  - Projektová dokumentace
  - Stavební povolení
  - Technické specifikace
  
- **Realizační fáze**
  - Harmonogram prací
  - Kontrolní protokoly
  - Revizní zprávy

- **Dokončovací fáze**
  - Kolaudační rozhodnutí
  - Předávací protokoly
  - Provozní dokumentace

## 2. PRODEJ TEPLA - SVJ/BD

### 2.1 Charakteristika produktu
- Řešení pro bytové domy
- Optimalizace nákladů na vytápění
- Profesionální správa
- Garantované úspory

### 2.2 Detailní prodejní proces
1. **První kontakt (osobní/telefonický)**
   - Identifikace potřeb
   - Základní představení řešení
   - Sběr vstupních dat
   - Domluvení osobní schůzky

2. **Schůzka s předsedou/výborem**
   - Detailní prezentace řešení
   - Ekonomická rozvaha
   - Technické možnosti
   - Harmonogram realizace

3. **Příprava podkladů pro shromáždění**
   - Ekonomická analýza
   - Technické řešení
   - Vizualizace
   - Referenční projekty

4. **Shromáždění vlastníků**
   - Prezentace řešení
   - Zodpovězení dotazů
   - Hlasování o realizaci

5. **Realizační fáze**
   - Příprava dokumentace
   - Stavební řízení
   - Instalace technologie
   - Předání do provozu

### 2.3 Klíčové dokumenty
- **Obchodní dokumentace**
  - Nájemní smlouva
  - Smlouva o dodávce tepla
  - Ekonomická rozvaha
  - Reference

- **Technická dokumentace**
  - Projektová dokumentace
  - Stavební povolení
  - Revizní zprávy
  - Provozní řád

## 3. PRODEJ TECHNOLOGIE

### 3.1 Charakteristika produktu
- Prodej technologického celku
- Vlastnictví technologie zákazníkem
- Možnost využití dotací
- Komplexní řešení na klíč

### 3.2 Procesní kroky
1. **Získání poptávky**
   - Zdroj poptávek
   - Evidence zákazníka
   - První kontakt

2. **Technické řešení**
   - Návštěva technika
   - Zaměření objektu
   - Návrh řešení
   - Rozpočet

3. **Příprava nabídky**
   - Technická specifikace
   - Cenová kalkulace
   - Dotační možnosti
   - Financování

4. **Realizační fáze**
   - Projektová dokumentace
   - Stavební povolení
   - Instalace
   - Zprovoznění

### 3.3 Dokumentace a administrativa
- **Před realizací**
  - Smlouva o dílo
  - Technická specifikace
  - Projektová dokumentace
  - Stavební povolení

- **Během realizace**
  - Stavební deník
  - Kontrolní protokoly
  - Revizní zprávy

- **Po realizaci**
  - Předávací protokol
  - Záruční list
  - Provozní dokumentace
  - Fakturace

## 4. FVE - SOUBĚH S TEPELNÝM ČERPADLEM

### 4.1 Charakteristika produktu
- Kombinované řešení
- Maximální energetická efektivita
- Dotační podpora
- Komplexní energetické řešení

### 4.2 Specifické kroky procesu
1. **Analýza objektu**
   - Posouzení střechy
   - Analýza spotřeby
   - Technické možnosti
   - Optimalizace výkonu

2. **Projektová příprava**
   - Návrh FVE
   - Návrh tepelného čerpadla
   - Integrace systémů
   - Dotační poradenství

3. **Realizace**
   - Koordinace instalací
   - Elektrické připojení
   - Uvedení do provozu
   - Monitoring systému

### 4.3 Potřebné dokumenty
- **Technická dokumentace**
  - Projektová dokumentace FVE
  - Projektová dokumentace TČ
  - Připojovací podmínky
  - Revizní zprávy

- **Dotační dokumentace**
  - Žádost o dotaci
  - Energetický posudek
  - Technická dokumentace
  - Faktury a doklady

## 5. FVE - SAMOSTATNÁ INSTALACE

### 5.1 Charakteristika produktu
- Samostatná fotovoltaická elektrárna
- Optimalizace pro vlastní spotřebu
- Bateriové úložiště
- Monitoring a řízení

### 5.2 Procesní postup
1. **Přípravná fáze**
   - Analýza spotřeby
   - Technická prohlídka
   - Návrh řešení
   - Kalkulace návratnosti

2. **Projektová dokumentace**
   - Návrh FVE
   - Elektro projekt
   - Statický posudek
   - Požární bezpečnost

3. **Realizace**
   - Instalace konstrukce
   - Montáž panelů
   - Elektroinstalace
   - Připojení a zprovoznění

### 5.3 Dokumenty a administrativa
- **Přípravná fáze**
  - Smlouva o dílo
  - Technická specifikace
  - Projektová dokumentace
  - Připojovací podmínky

- **Realizační fáze**
  - Revizní zprávy
  - Protokoly o instalaci
  - Dokumentace skutečného provedení
  - Předávací protokoly

## PRAKTICKÉ TIPY PRO OBCHODNÍKY

### Příprava na jednání
1. Prostudování specifik daného typu prodeje
2. Příprava referenčních projektů
3. Kalkulace a ekonomické podklady
4. Technické specifikace

### Vedení jednání
1. Identifikace potřeb zákazníka
2. Prezentace vhodného řešení
3. Vysvětlení procesu realizace
4. Řešení námitek

### Follow-up
1. Zápis z jednání
2. Stanovení dalších kroků
3. Příprava podkladů
4. Koordinace s technickým oddělením

## CHECKLIST PRO OBCHODNÍKY

### Před jednáním
- [ ] Analýza lokality
- [ ] Příprava podkladů
- [ ] Kontrola referencí
- [ ] Technické specifikace

### Během jednání
- [ ] Prezentace řešení
- [ ] Sběr informací
- [ ] Odpovědi na dotazy
- [ ] Stanovení dalších kroků

### Po jednání
- [ ] Zápis z jednání
- [ ] Odeslání podkladů
- [ ] Koordinace s týmem
- [ ] Plánování dalších kroků

