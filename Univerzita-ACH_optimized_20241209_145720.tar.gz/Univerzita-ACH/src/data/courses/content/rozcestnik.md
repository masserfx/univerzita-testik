# KURZ PRO OBCHODNÍKY AC HEATING

## 1. ÚVOD DO SPOLEČNOSTI

### 1.1 Historie a vize společnosti
- Založení 2006 (Michal Fiala a Lubomír Kuchynka)
- Vývoj od garáže po vlastní areál
- Přes 1500 instalací ročně
- Působnost v celé Evropě
- Více než 7500 úspěšných realizací

### 1.2 Firemní hodnoty a kultura
- Rodinná firma
- Jistota a stabilita
- Dodržování dohod
- Neformální prostředí
- Důraz na vzdělávání

## 2. PRODUKTOVÉ PORTFOLIO

### 2.1 Tepelná čerpadla
- AC Heating Convert AW
- BIG série (AW22-3P a AW28-3P)
- Technické specifikace a výhody
- Oblasti použití

### 2.2 Typy řešení
1. Prodej tepla
   - Pro developery
   - Pro SVJ/BD
2. Prodej technologie
3. Kombinovaná řešení s FVE

## 3. PRODEJNÍ PROCESY

### 3.1 Prodej tepla SVJ/BD
1. První kontakt
   - Zjištění situace CZT v lokalitě
   - Analýza domu pomocí map
   - Příprava orientačního přehledu úspor

2. Schůzka s předsedou
   - Prezentace řešení
   - Ekonomická rozvaha
   - Sběr technických informací
   - Analýza rizik

3. Schůzka s výborem
   - Prezentace financování
   - Ukázka referencí
   - Představení procesu realizace
   - Řešení námitek

4. Shromáždění vlastníků
   - Příprava prezentace
   - Technické řešení
   - Ekonomika provozu
   - Harmonogram realizace

### 3.2 Prodej developerům
1. Obchodní jednání
2. Technická součinnost
3. Smluvní dokumentace
4. Koordinace realizace

## 4. TECHNICKÉ ZNALOSTI

### 4.1 Základní principy
- Fungování tepelného čerpadla
- Topný faktor (COP)
- Dimenzování systému
- Regulace

### 4.2 Specifika instalací
- Napojení na stávající systém
- Požadavky na elektroinstalaci
- Umístění jednotek
- Hlukové parametry

## 5. DOKUMENTACE A ADMINISTRATIVA

### 5.1 Povinné dokumenty
- Smlouvy a jejich přílohy
- Technická dokumentace
- Revizní zprávy
- Kolaudační dokumentace

### 5.2 Firemní systémy
- EVI (CRM systém)
- Duplo (technické prohlídky)
- Evidence docházky
- Sdílený disk

## 6. PRAKTICKÉ DOVEDNOSTI

### 6.1 Komunikační dovednosti
- Prezentační techniky
- Řešení námitek
- Vedení jednání
- Argumentace

### 6.2 Technické dovednosti
- Práce s projektovou dokumentací
- Základní technické výpočty
- Orientace v normách a předpisech
- Práce s firemními systémy

## 7. BENEFITY A PRACOVNÍ PODMÍNKY

### 7.1 Pracovní zázemí
- Flexibilní pracovní doba
- Moderní kancelářské prostory
- Firemní oblečení
- IT vybavení

### 7.2 Zaměstnanecké výhody
- Káva na pracovišti
- Venkovní posezení
- Hotel Rohanov
- Firemní akce

## 8. KONTROLNÍ SEZNAM OBCHODNÍKA

### 8.1 Před jednáním
- [ ] Analýza lokality
- [ ] Příprava ekonomické rozvahy
- [ ] Kontrola referencí v okolí
- [ ] Příprava prezentačních materiálů

### 8.2 Během jednání
- [ ] Představení firmy
- [ ] Zjištění potřeb klienta
- [ ] Prezentace řešení
- [ ] Domluvení dalších kroků

### 8.3 Po jednání
- [ ] Zápis do CRM
- [ ] Odeslání podkladů
- [ ] Příprava nabídky
- [ ] Plánování následných kroků

