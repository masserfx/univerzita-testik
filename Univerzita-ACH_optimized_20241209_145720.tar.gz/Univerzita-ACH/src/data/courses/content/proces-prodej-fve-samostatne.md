# PROCESNÍ MAPA - SAMOSTATNÁ FVE INSTALACE

## 1. OBCHODNÍ FÁZE
### 1.1 Příjem a zpracování poptávky
- **Zodpovídá:** Back Office (BO)
- **Vyřizuje:** Back Office (BO)
- **Činnost:** Založení zákazníka v systému

### 1.2 Zpracování nabídky
- **Zodpovídá:** Obchodník (O)
- **Vyřizuje:** Obchodník (O)
- **Činnost:** Zpracování dotazníku a vytvoření indikativní nabídky

### 1.3 Technické posouzení
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Technik (T)
- **Činnosti:**
  - Návštěva technika na místě
  - Prohlídka objektu včetně posouzení:
    - Možností umístění panelů
    - Umístění střídače
    - Umístění baterie
    - Tras kabeláže
  - Vytvoření záznamu z prohlídky včetně fotodokumentace
  - Aktualizace rozpočtu po návštěvě

## 2. SMLUVNÍ DOKUMENTACE
### 2.1 Příprava smlouvy
- **Zodpovídá:** Back Office (BO)
- **Vyřizuje:** Back Office (BO)
- **Činnost:** Příprava smlouvy na FVE

### 2.2 Příprava příloh
- **Zodpovídá:** Obchodník (O)
- **Vyřizuje:** 
  - Back Office (BO): Obchodní podmínky, Plná moc
  - Technik (T): Specifikace materiálu
- **Přílohy:**
  1. Obchodní podmínky
  2. Specifikace materiálu
  3. Plná moc

### 2.3 Podpis smlouvy
- **Zodpovídá:** Obchodník (O)
- **Vyřizuje:** Obchodník (O)
- **Činnost:** Zajištění podpisu smlouvy a založení do šanonu

## 3. FINANČNÍ FÁZE
### 3.1 Platby
- **Zodpovídá:** Zákazník (Z)
- **Vyřizuje:** Zákazník (Z)
- **Činnost:** Úhrada 1. části zálohy dle SOD

### 3.2 Komponenty
- **Zodpovídá:** Back Office (BO)
- **Vyřizuje:** Back Office (BO)
- **Činnost:** Předobjednávka komponentů

## 4. DOTAČNÍ PROCES
### 4.1 Příprava dotace
- **Zodpovídá:** Back Office FVE (BFV)
- **Vyřizuje:** Back Office FVE (BFV)
- **Činnosti:**
  1. Zřízení e-identity
  2. Rozmístění panelů pro potřeby dotace
  3. Příprava technické dokumentace
  4. Vytvoření jednopólového schématu
  5. Zpracování v výpočtovém nástroji
  6. Elektronické podání žádosti
  7. Získání potvrzení o alokaci prostředků

## 5. PROJEKTOVÁ DOKUMENTACE
### 5.1 Zajištění podkladů
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Technik (T)
- **Požadované dokumenty:**
  - Stavební výkresy (1.PP, 1.NP, střecha, řez)
  - Projekt střechy (při nové střeše)
  - Požárně bezpečnostní řešení stavby (pro objekty po roce 1975)

### 5.2 Technické zakreslení
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Technik (T)
- **Činnosti:**
  1. Zakreslení technologie FVE
  2. Umístění FVE panelů na střeše a rozdělení do stringů
  3. Zakreslení tras DC a AC elektroinstalace
  4. Zakreslení umístění střídače, baterie a rozváděče R-FVE
  5. Zpracování instalační dokumentace
  6. Příprava technické dokumentace elektro

### 5.3 Konstrukční řešení
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Realizace FVE (RFV)
- **Činnost:** Volba typu konstrukce (MUEPRO/NOVOTEGRA/další)

### 5.4 Projektová dokumentace
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Projekce (P)
- **Dokumentace zahrnuje:**
  - Výkresová část:
    1. Půdorys 1.PP
    2. Půdorys 1.NP
    3. Půdorys typického podlaží
    4. Půdorys posledního podlaží
    5. Půdorys střechy
  - Statický posudek:
    1. Umístění panelů na střeše
    2. Zatížení konstrukce
  - Požárně bezpečnostní řešení stavby
  - Silnoproudá elektrotechnika:
    1. Smlouva s distributorem el. energie
    2. Technická dokumentace
    3. Jednopólové schéma zapojení
    4. Projekt hromosvodu (dle potřeby)

## 6. SCHVALOVACÍ PROCES
### 6.1 Schválení dokumentace
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Technik (T)
- **Činnost:** Předání projektové dokumentace DOSS (Hasičský záchranný sbor)

### 6.2 Předání k realizaci
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Koordinace realizace FVE (KRFV)
- **Činnost:** Předání projektu na realizaci

## 7. REALIZAČNÍ FÁZE
### 7.1 Zahájení realizace
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Technik (T)
- **Činnost:** Převzetí zakázky k realizaci

### 7.2 Příprava realizace
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Realizace FVE (RFV)
- **Činnosti:**
  1. Návrh rozváděče elektro
  2. Objednání a vyskladnění komponentů:
     - FV panely
     - Střídače
     - Baterie
     - Rozváděče R-FVE

### 7.3 Realizační práce
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Realizace FVE (RFV)
- **Činnosti:**
  1. Konstrukce a osazení FVE
  2. Elektroinstalační práce (AC a DC rozvody)
  3. Úprava elektroměrového rozváděče
  4. Osazení topných těles
  5. Osazení SSR rozváděče a propojení
  6. Propojení XCC přes LAN
  7. Zajištění propojení SEMS

### 7.4 Revize a dokumentace
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Realizace FVE (RFV)
- **Činnosti:**
  1. Revize elektrárny a odběrného místa
  2. Projektová dokumentace skutečného provedení

## 8. PŘIPOJENÍ K DISTRIBUČNÍ SÍTI
### 8.1 Příprava připojení
- **Zodpovídá:** Back Office FVE (BFV)
- **Vyřizuje:** Back Office FVE (BFV)
- **Činnosti:**
  1. Žádost o první paralelní připojení (PPP)
  2. Příprava dokumentů pro uvedení do provozu:
     - Smlouva o připojení
     - PDS odsouhlasená dokumentace
     - Jednopólové schéma
     - Revizní zprávy
     - Protokol o nastavení ochran
     - Instalační dokumenty

### 8.2 Připojení k síti
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Distributor (DISTR)
- **Činnosti:**
  1. Osazení 4Q elektroměru
  2. Protokol o PPP
  3. Zahájení plného provozu FVE včetně přetoků

## 9. DOKONČENÍ PROJEKTU
### 9.1 Předání díla
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Technická podpora (TP)
- **Činnost:** Předání zakázky zákazníkovi

### 9.2 Finanční vypořádání
- **Zodpovídá:** Zákazník (Z)
- **Vyřizuje:** Zákazník (Z)
- **Činnost:** Úhrada doplatku

### 9.3 Dotační administrativa
- **Zodpovídá:** Back Office FVE (BFV)
- **Vyřizuje:** Back Office FVE (BFV)
- **Činnosti:**
  1. Podání zprávy o realizaci na SFŽP
  2. Příprava podkladů:
     - Výpisy z účtu o platbách
     - Zpráva o instalaci FVE
     - Leták o příjmu dotace
  3. Získání rozhodnutí ministra o schválení dotace

### 9.4 Interní dokončení
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Koordinace realizace FVE (KRFV)
- **Činnost:** Kontrola výdejek

