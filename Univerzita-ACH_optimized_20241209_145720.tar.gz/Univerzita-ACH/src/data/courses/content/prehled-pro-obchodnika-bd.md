# Komplexní vzdělávací program pro obchodníky energetických řešení

## Obsah kurzu
1. Základní přehled produktového portfolia
2. Specifika jednotlivých typů prodeje
3. Prodejní proces krok za krokem
4. Praktické návody a postupy
5. Kontrolní seznamy pro obchodníky

## 1. Základní přehled produktového portfolia

### 1.1 Hlavní produktové linie
- Prodej tepla pro developery
- Prodej tepla pro SVJ/BD
- Prodej technologie
- Fotovoltaické elektrárny
  - V souběhu s tepelným čerpadlem
  - Samostatné instalace

### 1.2 Klíčové výhody jednotlivých řešení
- **Prodej tepla**
  - Minimální vstupní investice pro zákazníka
  - Profesionální správa a údržba
  - Garantované dodávky tepla
- **Prodej technologie**
  - Plná kontrola nad zařízením
  - Možnost využití dotací
  - Vlastní správa systému
- **Fotovoltaické elektrárny**
  - Snížení energetické závislosti
  - Ekologický zdroj energie
  - Kombinace s tepelným čerpadlem pro maximální efektivitu

## 2. Specifika jednotlivých typů prodeje

### 2.1 Prodej tepla pro developery
**Klíčové body:**
- Dlouhodobá spolupráce
- Technická součinnost při projekčních pracích
- Nutnost řešení věcných břemen a souvisejících smluv
- Důraz na včasnou koordinaci s výstavbou

**Potřebné dokumenty:**
- Smlouva o spolupráci
- Smlouva o zřízení služebnosti
- Smlouva o výhradě odděleného vlastnictví

### 2.2 Prodej tepla pro SVJ/BD
**Klíčové body:**
- Nutnost schválení shromážděním vlastníků
- Důležitost ekonomické rozvahy
- Řešení odpojení od CZT
- Příprava nájemní smlouvy

**Proces schvalování:**
1. První kontakt a prezentace řešení
2. Jednání s výborem
3. Příprava podkladů pro shromáždění
4. Schválení na shromáždění vlastníků

### 2.3 Prodej technologie
**Klíčové body:**
- Komplexní technické řešení
- Nutnost stavebního povolení
- Koordinace s dotačními programy
- Důraz na kvalitu projektové dokumentace

**Fáze prodeje:**
1. Úvodní analýza potřeb
2. Technické zaměření
3. Zpracování projektové dokumentace
4. Realizace a předání

## 3. Prodejní proces krok za krokem

### 3.1 První kontakt se zákazníkem
- Identifikace typu zákazníka
- Základní analýza potřeb
- Představení vhodného řešení
- Sběr vstupních dat

### 3.2 Příprava nabídky
- Technické posouzení
- Ekonomická rozvaha
- Návrh financování
- Prezentace řešení

### 3.3 Jednání a uzavření obchodu
- Řešení námitek
- Příprava smluvní dokumentace
- Koordinace s technickým oddělením
- Finalizace obchodu

## 4. Praktické návody a postupy

### 4.1 Příprava na jednání
**Checklist před jednáním:**
- Analýza lokality a současného stavu
- Příprava referenčních projektů
- Ekonomická rozvaha
- Technické podklady

### 4.2 Vedení obchodního jednání
**Klíčové body jednání:**
- Představení společnosti a řešení
- Zjištění potřeb a motivace
- Prezentace výhod
- Řešení námitek

### 4.3 Follow-up a další kroky
- Zápis z jednání
- Stanovení dalších kroků
- Koordinace s ostatními odděleními
- Časový harmonogram

## 5. Kontrolní seznamy pro obchodníky

### 5.1 Dokumenty potřebné pro jednotlivé typy prodejů
**Developer:**
- [ ] Smlouva o spolupráci
- [ ] Smlouva o zřízení služebnosti
- [ ] Projektová dokumentace
- [ ] Stavební povolení

**SVJ/BD:**
- [ ] Nájemní smlouva
- [ ] Ekonomická rozvaha
- [ ] Podklady pro shromáždění
- [ ] Technická specifikace

**Technologie:**
- [ ] Technická dokumentace
- [ ] Projektová dokumentace
- [ ] Stavební povolení
- [ ] Dotační podklady

### 5.2 Časová osa projektu
**Přípravná fáze:**
- Identifikace zákazníka
- První kontakt
- Analýza potřeb
- Příprava nabídky

**Realizační fáze:**
- Technické zaměření
- Projektová dokumentace
- Stavební řízení
- Realizace

**Dokončovací fáze:**
- Předání díla
- Dokumentace
- Zaškolení
- Servisní smlouva

## Závěr a doporučení pro praxi

### Klíčové faktory úspěchu:
1. Důkladná příprava na jednání
2. Znalost technických specifik
3. Schopnost vysvětlit výhody řešení
4. Profesionální přístup k dokumentaci
5. Efektivní komunikace s ostatními odděleními

### Doporučení pro další rozvoj:
- Pravidelné sledování novinek v oboru
- Sdílení zkušeností s kolegy
- Zpětná vazba od zákazníků
- Kontinuální vzdělávání

