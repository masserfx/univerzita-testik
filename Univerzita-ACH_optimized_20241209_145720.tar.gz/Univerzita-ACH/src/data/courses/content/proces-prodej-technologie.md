# PROCESNÍ MAPA - PRODEJ TECHNOLOGIE

## 1. ZÍSKÁVÁNÍ ZÁKAZNÍKŮ
### 1.1 Marketing a akvizice
**Zodpovídá:** Back Office (BO)
- Zdroje poptávek
- Slavnostní předání
- Reference ze zrealizovaných akcí
  - Zajištění provozních nákladů na referencích
- Dny otevřených dveří
- Cílené dopisy do lokalit s nejvyšší cenou tepla
- Partnerská spolupráce
- Správa archivu evidence
- Správa webu a Facebooku

### 1.2 Zpracování poptávky
**Zodpovídá:** Back Office (BO)
- Založení zákazníka v systému
- Evidence kontaktních údajů

## 2. OBCHODNÍ PROCES
### 2.1 První telefonický kontakt
**Zodpovídá:** Obchodník (O)
#### Příprava:
- Zjištění ceny tepla a situace CZT v lokalitě
- Prohlédnutí domu na mapě
- Zjištění referencí v okolí
- Orientační přehled úspor dle počtu bytů a konstrukcí

#### Obsah telefonátu:
- Upozornění na situaci s teplem v lokalitě
- Zjištění motivace ke změně
- Zjištění situace v domě

#### Cíl/výstup:
- Získání vstupních dat
- Domluvení dalšího postupu/schůzky
- Zápis v evidenci

### 2.2 Schůzka s předsedou/členem výboru
**Zodpovídá:** Obchodník (O)
#### Příprava:
- Nastudování historie komunikace
- Prostudování stanov (rozhodovací kvórum)
- Příprava ekonomické rozvahy a rozpočtu
- Materiály: notebook, katalog, leták, reference

#### Obsah jednání:
- Představení společnosti
- Analýza potřeb a obav
- Prezentace řešení a ekonomiky
- Nabídka návštěvy reference
- Sběr informací o domě:
  - Fond oprav
  - Věkové složení
  - Velikost bytových jednotek
  - Podmínky výpovědi CZT
- Zjištění rizikových bodů realizace

#### Cíl/výstup:
- Získání podpory předsedy
- Kompletace dat o domě
- Zjištění výpovědní lhůty CZT
- Domluvení setkání výboru
- Zápis v evidenci

### 2.3 Schůzka s výborem
**Zodpovídá:** Obchodník (O)
#### Příprava:
- Detailní přehled o situaci
- Varianty financování:
  - Koupě
  - Úvěr banka
  - Dodavatelský úvěr
  - TČ na zkoušku
  - 50/50
- Materiály pro prezentaci

#### Obsah:
- Představení společnosti
- Řešení potřeb a obav
- 3D prezentace a reference
- Prezentace ekonomiky a financování
- Představení procesu ankety
- Plán odpojení od CZT
- Pozvání na firmu
- Organizace shromáždění

#### Cíl/výstup:
- Jednotný výbor
- Domluvení návštěvy reference
- Plán ankety
- Řešení případných námitek

## 3. PŘÍPRAVNÁ FÁZE
### 3.1 Anketa
**Zodpovídá:** Obchodník (O)
- Zajištění mandátu výboru pro výběr dodavatele

### 3.2 Informativní shromáždění
**Zodpovídá:** Obchodník (O)
- Prezentace technického řešení
- Zodpovězení dotazů a námitek

### 3.3 Technické posouzení
**Zodpovídá:** Technik (T)
- Prohlídka objektu
- Zaměření napojovacích bodů
- Fotodokumentace
- Aktualizace rozpočtu

## 4. SCHVALOVACÍ PROCES
### 4.1 Mimořádné shromáždění vlastníků
**Zodpovídá:** Obchodník (O)
#### Příprava:
- Kompletní přehled o projektu
- Technické vybavení
- Předčasný příchod a koordinace s výborem

#### Cíl:
- Schválení změny vytápění
- Pověření výboru k uzavření smlouvy

## 5. SMLUVNÍ DOKUMENTACE
### 5.1 Příprava smlouvy
**Zodpovídá:** Obchodník (O)
- Návrh smlouvy
- Evidence nestandardních podmínek
- Příprava servisní smlouvy
- Zajištění smlouvy s dodavatelem tepla

### 5.2 Přílohy smlouvy
**Zodpovídá:** Obchodník (O)
- Rozpočet (označený "K PODPISU")
- Schéma zapojení
- Požadavky na připravenost
- Plná moc pro stavební povolení
- Zápis ze schůze včetně prezenční listiny

### 5.3 Finalizace smlouvy
**Zodpovídá:** Back Office (BO)
- Archivace podepsané smlouvy
- Potvrzení podpisu
- Řešení elektro přípojky

## 6. REALIZAČNÍ PŘÍPRAVA
### 6.1 Finanční část
**Zodpovídá:** Zákazník (Z)
- Úhrada první zálohy
- Potvrzení přijetí
- Předobjednávka komponentů

### 6.2 Připojení k distribuční síti
**Zodpovídá:** Back Office realizace (BR)
- Žádost o připojení
- Zajištění smlouvy o připojení
- Monitoring postupu

### 6.3 Projektová příprava
**Zodpovídá:** Technik (T)
- Předprojekční návštěva
- Zajištění podkladů
- Zpracování projektové dokumentace
- Získání stanovisek DOSS

## 7. REALIZACE
### 7.1 Etapa 1 - Příprava
**Zodpovídá:** Koordinace realizace (KRTC)
#### Administrativní příprava:
- Informování SVJ/BD
- Příprava dokumentace
- Koordinace subdodavatelů

#### Technická příprava:
- Elektroinstalace
- Stavební připravenost
- Topenářské práce

### 7.2 Etapa 2 - Realizace
**Zodpovídá:** Koordinace realizace (KRTC)
- Instalace technologie
- Připojení systémů
- Zprovoznění
- Měření a testy

## 8. DOKONČENÍ
### 8.1 Předání
**Zodpovídá:** Koordinace realizace (KRTC)
- Příprava dokumentace
- Zaškolení obsluhy
- Předávací protokol
- Vyúčtování

### 8.2 Kolaudace
**Zodpovídá:** Technik (T)
- Zajištění stanovisek
- Kolaudační řízení
- Získání kolaudačního souhlasu

### 8.3 Finanční vypořádání
**Zodpovídá:** Zákazník (Z)
- Úhrada doplatku
- Kontrola výdejek
- Archivace dokumentace

