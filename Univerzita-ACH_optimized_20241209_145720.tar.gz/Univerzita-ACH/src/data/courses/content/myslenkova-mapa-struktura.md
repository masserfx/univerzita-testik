# STRUKTURA VZDĚLÁVACÍCH MATERIÁLŮ

## 1. ZÁKLADNÍ MODULY
### 1.1 Obecné znalosti
- Energetický trh
- Legislativní rámec
- Technické základy
- Ekonomické principy

### 1.2 Produktové portfolio
- Tepelná řešení
- Fotovoltaické systémy
- Kombinovaná řešení
- Technologické celky

## 2. SPECIALIZAČNÍ MODULY
### 2.1 Prodej tepla
- Developer track
- SVJ/BD track

### 2.2 Prodej technologie
- Technické znalosti
- Procesní postupy
- Dokumentace

### 2.3 Fotovoltaika
- Samostatná instalace
- Kombinace s TČ

## 3. PROCESNÍ ZNALOSTI
### 3.1 Dokumentace
- Technická
- Právní
- Ekonomická

### 3.2 Kontrolní procesy
- Revize
- Termíny
- Předávací protokoly

### 3.3 Povolení a licence
- Stavební řízení
- Distributoři
- ERÚ

## 4. PRAKTICKÉ DOVEDNOSTI
### 4.1 Obchodní jednání
- První kontakt
- Prezentace
- Uzavření obchodu

### 4.2 Technická příprava
- Zaměření
- Projektová dokumentace
- Koordinace

### 4.3 Realizace
- Harmonogram
- Kontrola
- Předání

## 5. SDÍLENÉ ZNALOSTI
### 5.1 Best Practices
- Případové studie
- Řešení problémů
- Tipy a triky

### 5.2 Aktualizace
- Legislativa
- Technologie
- Procesy

