import { Course } from '../types';

export const procesProdejFveVSoubehuSTcCourse: Course = {
  id: 'proces-prodej-fve-v-soubehu-s-tc',
  title: 'Procesní mapa - FVE v souběhu s tepelným čerpadlem',
  description: 'Komplexní průvodce procesem prodeje a instalace fotovoltaiky v kombinaci s tepelným čerpadlem.',
  duration: '60 minut',
  level: 'advanced',
  tags: ['procesy', 'FVE', 'TČ', 'instalace', 'administrativa'],
  modules: [
    {
      id: 'obchodni-faze',
      title: 'Obchodní fáze',
      type: 'lesson',
      content: `# PROCESNÍ MAPA - FVE V SOUBĚHU S TEPELNÝM ČERPADLEM

## 1. OBCHODNÍ FÁZE
### 1.1 Příjem poptávky
**Zodpovídá:** Back Office (BO)
**Činnosti:**
- Založení zákazníka v systému
- Evidence základních údajů

### 1.2 Zpracování nabídky
**Zodpovídá:** Obchodník (O)
**Činnosti:**
- Zpracování dotazníku
- Vytvoření indikativní nabídky`
    },
    {
      id: 'technicke-posouzeni',
      title: 'Technické posouzení',
      type: 'lesson',
      content: `## 2. TECHNICKÉ POSOUZENÍ
### 2.1 Návštěva technika
**Zodpovídá:** Technik (T)
**Činnosti:**
- Prohlídka objektu:
  - Posouzení možností umístění panelů
  - Umístění střídače a baterie
  - Návrh tras kabeláže
- Vytvoření záznamu z prohlídky
- Pořízení fotodokumentace
- Aktualizace rozpočtu`
    },
    {
      id: 'smluvni-dokumentace',
      title: 'Smluvní dokumentace',
      type: 'lesson',
      content: `## 3. SMLUVNÍ DOKUMENTACE
### 3.1 Příprava smlouvy
**Zodpovídá:** Back Office (BO)
**Činnosti:**
- Příprava smlouvy na FVE

### 3.2 Přílohy smlouvy
**Zodpovídá:** Obchodník (O)
**Vyřizuje:**
- Back Office (BO): Obchodní podmínky, Plná moc
- Technik (T): Specifikace materiálu
**Přílohy:**
1. Obchodní podmínky
2. Specifikace materiálu
3. Plná moc

### 3.3 Podpis smlouvy
**Zodpovídá:** Obchodník (O)
**Činnosti:**
- Zajištění podpisu smlouvy
- Archivace v šanonu`
    },
    {
      id: 'financni-faze',
      title: 'Finanční fáze',
      type: 'lesson',
      content: `## 4. FINANČNÍ FÁZE
### 4.1 Úhrady
**Zodpovídá:** Zákazník (Z)
**Činnosti:**
- Úhrada 1. části zálohy dle SOD

### 4.2 Příprava komponent
**Zodpovídá:** Back Office (BO)
**Činnosti:**
- Předobjednávka komponentů

### 4.3 Úprava rozpočtu
**Zodpovídá:** Technik (T)
**Činnosti:**
- Kontrola/úprava rozpočtu TČ pro zohlednění topných těles`
    },
    {
      id: 'dotacni-proces',
      title: 'Dotační proces',
      type: 'lesson',
      content: `## 5. DOTAČNÍ PROCES
### 5.1 Dotační administrativa
**Zodpovídá:** Back Office realizace (BR)
**Činnosti:**
1. Zřízení e-identity
2. Rozmístění panelů pro dotaci
3. Příprava technické dokumentace
4. Zpracování jednopólového schématu
5. Práce s výpočtovým nástrojem
6. Elektronické podání žádosti
7. Získání potvrzení o alokaci`
    },
    {
      id: 'projektova-priprava',
      title: 'Projektová příprava',
      type: 'lesson',
      content: `## 6. PROJEKTOVÁ PŘÍPRAVA
### 6.1 Zajištění podkladů
**Zodpovídá:** Technik (T)
**Dokumenty:**
- Stavební výkresy (půdorysy, řezy)
- Projekt střechy
- Požárně bezpečnostní řešení

### 6.2 Technické zpracování
**Zodpovídá:** Technik (T)
**Činnosti:**
1. Zakreslení technologie FVE
2. Umístění a rozdělení panelů do stringů
3. Návrh tras DC a AC rozvodů
4. Umístění komponent (střídač, baterie, rozváděč)
5. Zpracování instalační dokumentace
6. Příprava elektro dokumentace
7. Volba konstrukčního systému

### 6.3 Projektová dokumentace
**Zodpovídá:** Technik (T)
**Vyřizuje:** Projekce (P)
**Obsah:**
1. Výkresová část:
   - Půdorysy všech podlaží
   - Střecha
2. Statický posudek
3. Požárně bezpečnostní řešení
4. Elektrotechnická část`
    },
    {
      id: 'priprava-realizace',
      title: 'Příprava realizace',
      type: 'lesson',
      content: `## 7. PŘÍPRAVA REALIZACE
### 7.1 Schválení dokumentace
**Zodpovídá:** Technik (T)
**Činnosti:**
- Předání dokumentace DOSS
- Předání projektu realizaci

### 7.2 Koordinace realizace
**Zodpovídá:** Koordinace realizace FVE (KRFV)
**Činnosti:**
- Převzetí zakázky
- Informování zákazníka o harmonogramu
- Koordinace s instalací TČ`
    },
    {
      id: 'stavebni-rizeni',
      title: 'Stavební řízení',
      type: 'lesson',
      content: `## 8. STAVEBNÍ ŘÍZENÍ
### 8.1 Příprava povolení
**Zodpovídá:** Back Office FVE (BFV)
**Činnosti:**
- Odhad získání pravomocného povolení
- Příprava žádosti o připojení

### 8.2 Připojení k distribuční síti
**Zodpovídá:** Back Office FVE (BFV)
**Dokumenty:**
- Jednopólové schéma
- Technická dokumentace
- Projektová dokumentace`
    },
    {
      id: 'realizacni-faze',
      title: 'Realizační fáze',
      type: 'lesson',
      content: `## 9. REALIZAČNÍ FÁZE
### 9.1 Koordinace prací
**Zodpovídá:** Koordinace realizace FVE (KRFV)
**Činnosti:**
- Koordinace TČ a FVE
- Návrh rozváděče
- Objednání komponent:
  - FV panely
  - Střídače
  - Baterie
  - Rozváděče

### 9.2 Realizace
**Zodpovídá:** Koordinace realizace FVE (KRFV)
**Vyřizuje:** Realizace FVE (RFV)
**Činnosti:**
1. Montáž konstrukce a panelů
2. Elektroinstalační práce
3. Úprava elektroměrového rozváděče
4. Osazení topných těles
5. Instalace a propojení systémů
6. Revize`
    },
    {
      id: 'pripojeni-a-zprovozneni',
      title: 'Připojení a zprovoznění',
      type: 'lesson',
      content: `## 10. PŘIPOJENÍ A ZPROVOZNĚNÍ
### 10.1 Dokumentace
**Zodpovídá:** Back Office FVE (BFV)
**Činnosti:**
- Projektová dokumentace skutečného provedení
- Žádost o první paralelní připojení
- Příprava dokumentů pro uvedení do provozu

### 10.2 Připojení
**Zodpovídá:** Back Office FVE (BFV)
**Vyřizuje:** Distributor (DISTR)
**Činnosti:**
- Osazení 4Q elektroměru
- Protokol o PPP
- Zahájení provozu

### 10.3 Zkušební provoz
**Zodpovídá:** Technická podpora (TP)
**Činnosti:**
- Zkušební provoz FVE 14 dní
- Monitoring systému`
    },
    {
      id: 'dokonceni-projektu',
      title: 'Dokončení projektu',
      type: 'lesson',
      content: `## 11. DOKONČENÍ PROJEKTU
### 11.1 Předání
**Zodpovídá:** Koordinace realizace FVE (KRFV)
**Vyřizuje:** Technická podpora (TP)
**Činnosti:**
- Předání zakázky zákazníkovi

### 11.2 Finanční vypořádání
**Zodpovídá:** Zákazník (Z)
**Činnosti:**
- Úhrada doplatku

### 11.3 Dotační vyúčtování
**Zodpovídá:** Back Office realizace (BR)
**Činnosti:**
1. Podání zprávy o realizaci
2. Doložení dokumentů:
   - Výpisy z účtu
   - Zpráva o instalaci
   - Leták o dotaci
3. Získání rozhodnutí o schválení dotace

### 11.4 Interní dokončení
**Zodpovídá:** Koordinace realizace FVE (KRFV)
**Činnosti:**
- Kontrola výdejek
- Uzavření projektu`
    }
  ]
}; 