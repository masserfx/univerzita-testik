import { Course } from '../types';

export const procesProdejTechnologieCourse: Course = {
  id: 'proces-prodej-technologie',
  title: 'Procesní mapa - Prodej technologie',
  description: 'Komplexní průvodce procesem prodeje technologie, od získávání zákazníků až po dokončení a kolaudaci.',
  duration: '60 minut',
  level: 'intermediate',
  tags: ['procesy', 'prodej', 'technologie', 'administrativa', 'realizace'],
  modules: [
    {
      id: 'ziskavani-zakazniku',
      title: 'Získávání zákazníků',
      type: 'lesson',
      content: `# Získávání zákazníků

### Marketing a akvizice
**Zodpovídá:** Back Office (BO)
- Zdroje poptávek
- Slavnostní předání
- Reference ze zrealizovaných akcí
  - Zajištění provozních nákladů na referencích
- Dny otevřených dveří
- Cílené dopisy do lokalit s nejvyšší cenou tepla
- Partnerská spolupráce
- Správa archivu evidence
- Správa webu a Facebooku

### Zpracování poptávky
**Zodpovídá:** Back Office (BO)
- Založení zákazníka v systému
- Evidence kontaktních údajů`
    },
    {
      id: 'obchodni-proces',
      title: 'Obchodní proces',
      type: 'lesson',
      content: `# Obchodní proces

### První telefonický kontakt
**Zodpovídá:** Obchodník (O)
#### Příprava:
- Zjištění ceny tepla a situace CZT v lokalitě
- Prohlédnutí domu na mapě
- Zjištění referencí v okolí
- Orientační přehled úspor dle počtu bytů a konstrukcí

#### Obsah telefonátu:
- Upozornění na situaci s teplem v lokalitě
- Zjištění motivace ke změně
- Zjištění situace v domě

#### Cíl/výstup:
- Získání vstupních dat
- Domluvení dalšího postupu/schůzky
- Zápis v evidenci

### Schůzka s předsedou/členem výboru
**Zodpovídá:** Obchodník (O)
#### Příprava:
- Nastudování historie komunikace
- Prostudování stanov (rozhodovací kvórum)
- Příprava ekonomické rozvahy a rozpočtu
- Materiály: notebook, katalog, leták, reference

#### Obsah jednání:
- Představení společnosti
- Analýza potřeb a obav
- Prezentace řešení a ekonomiky
- Nabídka návštěvy reference
- Sběr informací o domě:
  - Fond oprav
  - Věkové složení
  - Velikost bytových jednotek
  - Podmínky výpovědi CZT
- Zjištění rizikových bodů realizace

#### Cíl/výstup:
- Získání podpory předsedy
- Kompletace dat o domě
- Zjištění výpovědní lhůty CZT
- Domluvení setkání výboru
- Zápis v evidenci

### Schůzka s výborem
**Zodpovídá:** Obchodník (O)
#### Příprava:
- Detailní přehled o situaci
- Varianty financování:
  - Koupě
  - Úvěr banka
  - Dodavatelský úvěr
  - TČ na zkoušku
  - 50/50
- Materiály pro prezentaci

#### Obsah:
- Představení společnosti
- Řešení potřeb a obav
- 3D prezentace a reference
- Prezentace ekonomiky a financování
- Představení procesu ankety
- Plán odpojení od CZT
- Pozvání na firmu
- Organizace shromáždění

#### Cíl/výstup:
- Jednotný výbor
- Domluvení návštěvy reference
- Plán ankety
- Řešení případných námitek`
    },
    {
      id: 'pripravna-faze',
      title: 'Přípravná fáze',
      type: 'lesson',
      content: `# Přípravná fáze

### Anketa
**Zodpovídá:** Obchodník (O)
- Zajištění mandátu výboru pro výběr dodavatele

### Informativní shromáždění
**Zodpovídá:** Obchodník (O)
- Prezentace technického řešení
- Zodpovězení dotazů a námitek

### Technické posouzení
**Zodpovídá:** Technik (T)
- Prohlídka objektu
- Zaměření napojovacích bodů
- Fotodokumentace
- Aktualizace rozpočtu`
    },
    {
      id: 'schvalovaci-proces',
      title: 'Schvalovací proces',
      type: 'lesson',
      content: `# Schvalovací proces

### Mimořádné shromáždění vlastníků
**Zodpovídá:** Obchodník (O)
#### Příprava:
- Kompletní přehled o projektu
- Technické vybavení
- Předčasný příchod a koordinace s výborem

#### Cíl:
- Schválení změny vytápění
- Pověření výboru k uzavření smlouvy`
    },
    {
      id: 'smluvni-dokumentace',
      title: 'Smluvní dokumentace',
      type: 'lesson',
      content: `# Smluvní dokumentace

### Příprava smlouvy
**Zodpovídá:** Obchodník (O)
- Návrh smlouvy
- Evidence nestandardních podmínek
- Příprava servisní smlouvy
- Zajištění smlouvy s dodavatelem tepla

### Přílohy smlouvy
**Zodpovídá:** Obchodník (O)
- Rozpočet (označený "K PODPISU")
- Schéma zapojení
- Požadavky na připravenost
- Plná moc pro stavební povolení
- Zápis ze schůze včetně prezenční listiny

### Finalizace smlouvy
**Zodpovídá:** Back Office (BO)
- Archivace podepsané smlouvy
- Potvrzení podpisu
- Řešení elektro přípojky`
    },
    {
      id: 'realizacni-priprava',
      title: 'Realizační příprava',
      type: 'lesson',
      content: `# Realizační příprava

### Finanční část
**Zodpovídá:** Zákazník (Z)
- Úhrada první zálohy
- Potvrzení přijetí
- Předobjednávka komponentů

### Připojení k distribuční síti
**Zodpovídá:** Back Office realizace (BR)
- Žádost o připojení
- Zajištění smlouvy o připojení
- Monitoring postupu

### Projektová příprava
**Zodpovídá:** Technik (T)
- Předprojekční návštěva
- Zajištění podkladů
- Zpracování projektové dokumentace
- Získání stanovisek DOSS`
    },
    {
      id: 'realizace',
      title: 'Realizace',
      type: 'lesson',
      content: `# Realizace

### Etapa 1 - Příprava
**Zodpovídá:** Koordinace realizace (KRTC)
#### Administrativní příprava:
- Informování SVJ/BD
- Příprava dokumentace
- Koordinace subdodavatelů

#### Technická příprava:
- Elektroinstalace
- Stavební připravenost
- Topenářské práce

### Etapa 2 - Realizace
**Zodpovídá:** Koordinace realizace (KRTC)
- Instalace technologie
- Připojení systémů
- Zprovoznění
- Měření a testy`
    },
    {
      id: 'dokonceni',
      title: 'Dokončení',
      type: 'lesson',
      content: `# Dokončení

### Předání
**Zodpovídá:** Koordinace realizace (KRTC)
- Příprava dokumentace
- Zaškolení obsluhy
- Předávací protokol
- Vyúčtování

### Kolaudace
**Zodpovídá:** Technik (T)
- Zajištění stanovisek
- Kolaudační řízení
- Získání kolaudačního souhlasu

### Finanční vypořádání
**Zodpovídá:** Zákazník (Z)
- Úhrada doplatku
- Kontrola výdejek
- Archivace dokumentace`
    }
  ]
}; 