import { Course } from '../types';

export const procesProdejFveSamostatneCourse: Course = {
  id: 'proces-prodej-fve-samostatne',
  title: 'Procesní mapa - Samostatná FVE instalace',
  description: 'Komplexní průvodce procesem prodeje a instalace samostatné fotovoltaické elektrárny, od obchodní fáze až po dokončení projektu.',
  duration: '60 minut',
  level: 'intermediate',
  tags: ['procesy', 'FVE', 'fotovoltaika', 'administrativa', 'realizace'],
  modules: [
    {
      id: 'obchodni-faze',
      title: 'Obchodní fáze',
      type: 'lesson',
      content: `# Obchodní fáze

### Příjem a zpracování poptávky
- **Zodpovídá:** Back Office (BO)
- **Vyřizuje:** Back Office (BO)
- **Činnost:** Založení zákazníka v systému

### Zpracování nabídky
- **Zodpovídá:** Obchodník (O)
- **Vyřizuje:** Obchodník (O)
- **Činnost:** Zpracování dotazníku a vytvoření indikativní nabídky

### Technické posouzení
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Technik (T)
- **Činnosti:**
  - Návštěva technika na místě
  - Prohlídka objektu včetně posouzení:
    - Možností umístění panelů
    - Umístění střídače
    - Umístění baterie
    - Tras kabeláže
  - Vytvoření záznamu z prohlídky včetně fotodokumentace
  - Aktualizace rozpočtu po návštěvě`
    },
    {
      id: 'smluvni-dokumentace',
      title: 'Smluvní dokumentace',
      type: 'lesson',
      content: `# Smluvní dokumentace

### Příprava smlouvy
- **Zodpovídá:** Back Office (BO)
- **Vyřizuje:** Back Office (BO)
- **Činnost:** Příprava smlouvy na FVE

### Příprava příloh
- **Zodpovídá:** Obchodník (O)
- **Vyřizuje:** 
  - Back Office (BO): Obchodní podmínky, Plná moc
  - Technik (T): Specifikace materiálu
- **Přílohy:**
  1. Obchodní podmínky
  2. Specifikace materiálu
  3. Plná moc

### Podpis smlouvy
- **Zodpovídá:** Obchodník (O)
- **Vyřizuje:** Obchodník (O)
- **Činnost:** Zajištění podpisu smlouvy a založení do šanonu`
    },
    {
      id: 'financni-faze',
      title: 'Finanční fáze',
      type: 'lesson',
      content: `# Finanční fáze

### Platby
- **Zodpovídá:** Zákazník (Z)
- **Vyřizuje:** Zákazník (Z)
- **Činnost:** Úhrada 1. části zálohy dle SOD

### Komponenty
- **Zodpovídá:** Back Office (BO)
- **Vyřizuje:** Back Office (BO)
- **Činnost:** Předobjednávka komponentů`
    },
    {
      id: 'dotacni-proces',
      title: 'Dotační proces',
      type: 'lesson',
      content: `# Dotační proces

### Příprava dotace
- **Zodpovídá:** Back Office FVE (BFV)
- **Vyřizuje:** Back Office FVE (BFV)
- **Činnosti:**
  1. Zřízení e-identity
  2. Rozmístění panelů pro potřeby dotace
  3. Příprava technické dokumentace
  4. Vytvoření jednopólového schématu
  5. Zpracování v výpočtovém nástroji
  6. Elektronické podání žádosti
  7. Získání potvrzení o alokaci prostředků`
    },
    {
      id: 'projektova-dokumentace',
      title: 'Projektová dokumentace',
      type: 'lesson',
      content: `# Projektová dokumentace

### Zajištění podkladů
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Technik (T)
- **Požadované dokumenty:**
  - Stavební výkresy (1.PP, 1.NP, střecha, řez)
  - Projekt střechy (při nové střeše)
  - Požárně bezpečnostní řešení stavby (pro objekty po roce 1975)

### Technické zakreslení
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Technik (T)
- **Činnosti:**
  1. Zakreslení technologie FVE
  2. Umístění FVE panelů na střeše a rozdělení do stringů
  3. Zakreslení tras DC a AC elektroinstalace
  4. Zakreslení umístění střídače, baterie a rozváděče R-FVE
  5. Zpracování instalační dokumentace
  6. Příprava technické dokumentace elektro

### Konstrukční řešení
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Realizace FVE (RFV)
- **Činnost:** Volba typu konstrukce (MUEPRO/NOVOTEGRA/další)

### Projektová dokumentace
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Projekce (P)
- **Dokumentace zahrnuje:**
  - Výkresová část:
    1. Půdorys 1.PP
    2. Půdorys 1.NP
    3. Půdorys typického podlaží
    4. Půdorys posledního podlaží
    5. Půdorys střechy
  - Statický posudek:
    1. Umístění panelů na střeše
    2. Zatížení konstrukce
  - Požárně bezpečnostní řešení stavby
  - Silnoproudá elektrotechnika:
    1. Smlouva s distributorem el. energie
    2. Technická dokumentace
    3. Jednopólové schéma zapojení
    4. Projekt hromosvodu (dle potřeby)`
    },
    {
      id: 'schvalovaci-proces',
      title: 'Schvalovací proces',
      type: 'lesson',
      content: `# Schvalovací proces

### Schválení dokumentace
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Technik (T)
- **Činnost:** Předání projektové dokumentace DOSS (Hasičský záchranný sbor)

### Předání k realizaci
- **Zodpovídá:** Technik (T)
- **Vyřizuje:** Koordinace realizace FVE (KRFV)
- **Činnost:** Předání projektu na realizaci`
    },
    {
      id: 'realizacni-faze',
      title: 'Realizační fáze',
      type: 'lesson',
      content: `# Realizační fáze

### Zahájení realizace
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Technik (T)
- **Činnost:** Převzetí zakázky k realizaci

### Příprava realizace
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Realizace FVE (RFV)
- **Činnosti:**
  1. Návrh rozváděče elektro
  2. Objednání a vyskladnění komponentů:
     - FV panely
     - Střídače
     - Baterie
     - Rozváděče R-FVE

### Realizační práce
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Realizace FVE (RFV)
- **Činnosti:**
  1. Konstrukce a osazení FVE
  2. Elektroinstalační práce (AC a DC rozvody)
  3. Úprava elektroměrového rozváděče
  4. Osazení topných těles
  5. Osazení SSR rozváděče a propojení
  6. Propojení XCC přes LAN
  7. Zajištění propojení SEMS

### Revize a dokumentace
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Realizace FVE (RFV)
- **Činnosti:**
  1. Revize elektrárny a odběrného místa
  2. Projektová dokumentace skutečného provedení`
    },
    {
      id: 'pripojeni-k-distribucni-siti',
      title: 'Připojení k distribuční síti',
      type: 'lesson',
      content: `# Připojení k distribuční síti

### Příprava připojení
- **Zodpovídá:** Back Office FVE (BFV)
- **Vyřizuje:** Back Office FVE (BFV)
- **Činnosti:**
  1. Žádost o první paralelní připojení (PPP)
  2. Příprava dokumentů pro uvedení do provozu:
     - Smlouva o připojení
     - PDS odsouhlasená dokumentace
     - Jednopólové schéma
     - Revizní zprávy
     - Protokol o nastavení ochran
     - Instalační dokumenty

### Připojení k síti
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Distributor (DISTR)
- **Činnosti:**
  1. Osazení 4Q elektroměru
  2. Protokol o PPP
  3. Zahájení plného provozu FVE včetně přetoků`
    },
    {
      id: 'dokonceni-projektu',
      title: 'Dokončení projektu',
      type: 'lesson',
      content: `# Dokončení projektu

### Předání díla
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Technická podpora (TP)
- **Činnost:** Předání zakázky zákazníkovi

### Finanční vypořádání
- **Zodpovídá:** Zákazník (Z)
- **Vyřizuje:** Zákazník (Z)
- **Činnost:** Úhrada doplatku

### Dotační administrativa
- **Zodpovídá:** Back Office FVE (BFV)
- **Vyřizuje:** Back Office FVE (BFV)
- **Činnosti:**
  1. Podání zprávy o realizaci na SFŽP
  2. Příprava podkladů:
     - Výpisy z účtu o platbách
     - Zpráva o instalaci FVE
     - Leták o příjmu dotace
  3. Získání rozhodnutí ministra o schválení dotace

### Interní dokončení
- **Zodpovídá:** Koordinace realizace FVE (KRFV)
- **Vyřizuje:** Koordinace realizace FVE (KRFV)
- **Činnost:** Kontrola výdejek`
    }
  ]
}; 