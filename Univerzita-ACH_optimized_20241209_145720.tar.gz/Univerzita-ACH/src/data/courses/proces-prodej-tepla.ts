import { Course } from '../types';

export const procesProdejTeplaCourse: Course = {
  id: 'proces-prodej-tepla',
  title: 'Procesní mapa - Prodej tepla SVJ/BD',
  description: 'Komplexní průvodce procesem prodeje tepla pro SVJ a bytová družstva, od smluvní dokumentace až po kontrolní procesy.',
  duration: '60 minut',
  level: 'advanced',
  tags: ['procesy', 'SVJ', 'BD', 'teplo', 'administrativa'],
  modules: [
    {
      id: 'smluvni-dokumentace',
      title: 'Smluvní dokumentace',
      type: 'lesson',
      content: `# PROCESNÍ MAPA - PRODEJ TEPLA SVJ/BD

## 1. SMLUVNÍ DOKUMENTACE
### 1.1 Nájemní smlouva
**Zodpovídá:** Obchodník (O)
**Dokumenty:**
- Nájemní smlouva
- Vzor smlouvy o prodeji tepelné energie

### 1.2 Přílohy nájemní smlouvy
**Zodpovídá:** Obchodník (O)
**Vyřizuje:** 
- Technik (T):
  - Příloha č.1 - Schéma zapojení + obchodní nabídka
  - Příloha č.2 - Podmínky připravenosti objektu
- Back Office (BO):
  - Příloha č.3 - Vzor smlouvy o dodávce tepla
  - Příloha č.4 - Zápis ze shromáždění

### 1.3 Smlouva o dodávce tepla
**Zodpovídá:** Obchodník (O)
**Vyřizuje:** Obchodník (O) + Zákazník (Z)
**Přílohy:**
1. Technické parametry a specifikace odběrného místa
2. Platební kalendář
3. Kalkulace kupní ceny tepelného zařízení
4. Obchodní podmínky dodavatele tepla`
    },
    {
      id: 'technicka-priprava',
      title: 'Technická příprava',
      type: 'lesson',
      content: `## 2. TECHNICKÁ PŘÍPRAVA
### 2.1 Projektová dokumentace
**Zodpovídá:** Technik (T)
**Činnosti:**
- Odeslání PD pro odsouhlasení pronajímateli
- Zajištění zkušebního provozu
- Zajištění stanovisek dotčených orgánů

### 2.2 Stanoviska dotčených orgánů
**Zodpovídá:** Technik (T)
**Činnosti:**
- Hasičský záchranný sbor
  - Zajištění revizí
  - Prohlášení o materiálech
  - Místní šetření
- Odbor životního prostředí
- Krajská hygienická stanice
  - Protokol z měření hluku`
    },
    {
      id: 'pripojeni-k-distribucni-siti',
      title: 'Připojení k distribuční síti',
      type: 'lesson',
      content: `## 3. PŘIPOJENÍ K DISTRIBUČNÍ SÍTI
### 3.1 Elektrické připojení
**Zodpovídá:** Back Office realizace (BR)
**Činnosti:**
- Uzavření smlouvy na dodávku elektřiny (sazba C56d)
  - Termín: do 20.5.2024 (TEDOM Energie)
**Potřebné dokumenty:**
- Smlouva o připojení od distributora
- Revizní zpráva
- Potvrzení o instalaci TČ
- Potvrzení osazení elektroměru (min. 30 dní před přepojením)`
    },
    {
      id: 'licencovani-a-administrativa',
      title: 'Licencování a administrativa',
      type: 'lesson',
      content: `## 4. LICENCOVÁNÍ A ADMINISTRATIVA
### 4.1 Licence na prodej tepla
**Zodpovídá:** Back Office realizace (BR)
**Potřebné dokumenty:**
1. Plná moc (při zastupování)
2. Výpis z obchodního rejstříku
3. Žádost o změnu licence
4. Seznam provozoven
5. Výpis z listu vlastnictví
6. Koordinační situační výkres
7. Nájemní smlouva
8. Předávací protokol
9. Schéma zapojení
10. Fotodokumentace výrobních štítků
11. Evidenční kniha
12. Provozní řád
13. Technické listy
14. Revize (elektro, tlakové nádoby)
15. Kolaudační souhlas`
    },
    {
      id: 'ekonomicke-procesy',
      title: 'Ekonomické procesy',
      type: 'lesson',
      content: `## 5. EKONOMICKÉ PROCESY
### 5.1 Základní nastavení
**Zodpovídá:** Back Office (BO)
**Činnosti:**
- Nastavení plateb záloh
- Potvrzení kupní smlouvy
- Zajištění fakturace nákladů

### 5.2 Výkaznictví ERÚ
**Zodpovídá:** Back Office (BO)
**Termíny:**
1. Do 31. ledna:
   - Oznámení cen tepla
   - Výkaz cen a technických parametrů
2. Do 30. dubna:
   - Výkaz cenová lokalita
   - Výkaz aktiva a pasiva

### 5.3 Pravidelné činnosti
**Zodpovídá:** Back Office (BO)
**Činnosti:**
- Zajištění faktur za elektrickou energii
- Evidence servisních činností a oprav
- Odečty dodaného tepla
- Příprava cenových oznámení`
    },
    {
      id: 'kontrolni-procesy',
      title: 'Kontrolní procesy',
      type: 'lesson',
      content: `## 6. KONTROLNÍ PROCESY
### 6.1 Pravidelné kontroly
- [ ] Měsíční kontrola fakturace
- [ ] Čtvrtletní odečty
- [ ] Roční vyúčtování
- [ ] Kontrola revizí

### 6.2 Termínované úkony
- [ ] Předání výkazů ERÚ
- [ ] Aktualizace cen
- [ ] Kontrola platnosti dokumentů
- [ ] Obnova revizí`
    },
    {
      id: 'dokumentace',
      title: 'Dokumentace',
      type: 'lesson',
      content: `## 7. DOKUMENTACE
### 7.1 Provozní dokumentace
- Provozní řád
- Evidenční kniha
- Revizní zprávy
- Technická dokumentace

### 7.2 Ekonomická dokumentace
- Faktury
- Výkazy ERÚ
- Platební kalendáře
- Cenová rozhodnutí`
    }
  ]
}; 