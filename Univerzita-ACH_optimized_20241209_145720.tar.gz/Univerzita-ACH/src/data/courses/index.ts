import { Course } from '../types';
import { eviSystem } from './evi';
import { zakazkyCourse } from './zakazky';
import { testUiCourse } from './test-ui';
import { uvodDoACHeating } from './uvod';
import { instalaceTepelnychCerpadel } from './instalace';
import { pravidlaNabidek } from './nabidky';
import { obchodniProcesBD } from './obchodni-proces-bd';
import { vytapenipanelakuCourse } from './vytapenipanelaku';
import { procesProdejTeplaCourse } from './proces-prodej-tepla';
import { procesProdejTeplaDevCourse } from './proces-prodej-tepla-developer';
import { procesProdejTechnologieCourse } from './proces-prodej-technologie';
import { procesProdejFveSamostatneCourse } from './proces-prodej-fve-samostatne';
import { procesProdejFveVSoubehuSTcCourse } from './proces-prodej-fve-v-soubehu-s-tc';
import { produktovePortfolioBDCourse } from './produktove-portfolio-bd';
import { prehledProObchodnikaBDCourse } from './prehled-pro-obchodnika-bd';
import { myslenkovaMapaObchodniProcesCourse } from './myslenkova-mapa-obchodni-proces';
import { rozcestnikCourse } from './rozcestnik';

export const courses: Course[] = [
  rozcestnikCourse,
  testUiCourse,
  uvodDoACHeating,
  instalaceTepelnychCerpadel,
  pravidlaNabidek,
  eviSystem,
  obchodniProcesBD,
  vytapenipanelakuCourse,
  zakazkyCourse,
  procesProdejTeplaCourse,
  procesProdejTeplaDevCourse,
  procesProdejTechnologieCourse,
  procesProdejFveSamostatneCourse,
  procesProdejFveVSoubehuSTcCourse,
  produktovePortfolioBDCourse,
  prehledProObchodnikaBDCourse,
  myslenkovaMapaObchodniProcesCourse,
]; 