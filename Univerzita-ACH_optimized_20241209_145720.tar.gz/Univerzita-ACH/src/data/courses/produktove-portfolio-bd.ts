import { Course } from '../types';

export const produktovePortfolioBDCourse: Course = {
  id: 'produktove-portfolio-bd',
  title: 'Příručka pro obchodníky - Produktové portfolio',
  description: 'Komplexní průvodce produktovým portfoliem pro obchodníky, zahrnující prodej tepla, technologie a FVE řešení.',
  duration: '45 minut',
  level: 'intermediate',
  tags: ['obchod', 'produkty', 'portfolio', 'teplo', 'FVE', 'technologie'],
  modules: [
    {
      id: 'prodej-tepla-developer',
      title: 'Prodej tepla - Developer',
      type: 'lesson',
      content: `# Prodej tepla - Developer

### Charakteristika produktu
- Komplexní řešení pro developery
- Dlouhodobé partnerství
- Minimální vstupní investice
- Profesionální správa systému

### Procesní postup
1. **Obchodní jednání**
   - Představení společnosti
   - Analýza potřeb developera
   - Prezentace řešení
   - Předběžná kalkulace

2. **Technická součinnost**
   - Spolupráce při projekčních pracích
   - Konzultace technického řešení
   - Optimalizace návrhu

3. **Smluvní dokumentace**
   - Smlouva o spolupráci
   - Smlouva o zřízení služebnosti
   - Smlouva o výhradě odděleného vlastnictví
   - Smlouva o dodávce tepla

4. **Stavební fáze**
   - Koordinace s výstavbou
   - Technický dozor
   - Kontrola připravenosti

5. **Dokončení a předání**
   - Kolaudace
   - Předávací protokoly
   - Zahájení dodávek tepla

### Potřebná dokumentace
- **Přípravná fáze**
  - Projektová dokumentace
  - Stavební povolení
  - Technické specifikace
  
- **Realizační fáze**
  - Harmonogram prací
  - Kontrolní protokoly
  - Revizní zprávy

- **Dokončovací fáze**
  - Kolaudační rozhodnutí
  - Předávací protokoly
  - Provozní dokumentace`
    },
    {
      id: 'prodej-tepla-svj-bd',
      title: 'Prodej tepla - SVJ/BD',
      type: 'lesson',
      content: `# Prodej tepla - SVJ/BD

### Charakteristika produktu
- Řešení pro bytové domy
- Optimalizace nákladů na vytápění
- Profesionální správa
- Garantované úspory

### Detailní prodejní proces
1. **První kontakt (osobní/telefonický)**
   - Identifikace potřeb
   - Základní představení řešení
   - Sběr vstupních dat
   - Domluvení osobní schůzky

2. **Schůzka s předsedou/výborem**
   - Detailní prezentace řešení
   - Ekonomická rozvaha
   - Technické možnosti
   - Harmonogram realizace

3. **Příprava podkladů pro shromáždění**
   - Ekonomická analýza
   - Technické řešení
   - Vizualizace
   - Referenční projekty

4. **Shromáždění vlastníků**
   - Prezentace řešení
   - Zodpovězení dotazů
   - Hlasování o realizaci

5. **Realizační fáze**
   - Příprava dokumentace
   - Stavební řízení
   - Instalace technologie
   - Předání do provozu

### Klíčové dokumenty
- **Obchodní dokumentace**
  - Nájemní smlouva
  - Smlouva o dodávce tepla
  - Ekonomická rozvaha
  - Reference

- **Technická dokumentace**
  - Projektová dokumentace
  - Stavební povolení
  - Revizní zprávy
  - Provozní řád`
    },
    {
      id: 'prodej-technologie',
      title: 'Prodej technologie',
      type: 'lesson',
      content: `# Prodej technologie

### Charakteristika produktu
- Prodej technologického celku
- Vlastnictví technologie zákazníkem
- Možnost využití dotací
- Komplexní řešení na klíč

### Procesní kroky
1. **Získání poptávky**
   - Zdroj poptávek
   - Evidence zákazníka
   - První kontakt

2. **Technické řešení**
   - Návštěva technika
   - Zaměření objektu
   - Návrh řešení
   - Rozpočet

3. **Příprava nabídky**
   - Technická specifikace
   - Cenová kalkulace
   - Dotační možnosti
   - Financování

4. **Realizační fáze**
   - Projektová dokumentace
   - Stavební povolení
   - Instalace
   - Zprovoznění

### Dokumentace a administrativa
- **Před realizací**
  - Smlouva o dílo
  - Technická specifikace
  - Projektová dokumentace
  - Stavební povolení

- **Během realizace**
  - Stavební deník
  - Kontrolní protokoly
  - Revizní zprávy

- **Po realizaci**
  - Předávací protokol
  - Záruční list
  - Provozní dokumentace
  - Fakturace`
    },
    {
      id: 'fve-soubeh-s-tc',
      title: 'FVE - Souběh s tepelným čerpadlem',
      type: 'lesson',
      content: `# FVE - Souběh s tepelným čerpadlem

### Charakteristika produktu
- Kombinované řešení
- Maximální energetická efektivita
- Dotační podpora
- Komplexní energetické řešení

### Specifické kroky procesu
1. **Analýza objektu**
   - Posouzení střechy
   - Analýza spotřeby
   - Technické možnosti
   - Optimalizace výkonu

2. **Projektová příprava**
   - Návrh FVE
   - Návrh tepelného čerpadla
   - Integrace systémů
   - Dotační poradenství

3. **Realizace**
   - Koordinace instalací
   - Elektrické připojení
   - Uvedení do provozu
   - Monitoring systému

### Potřebné dokumenty
- **Technická dokumentace**
  - Projektová dokumentace FVE
  - Projektová dokumentace TČ
  - Připojovací podmínky
  - Revizní zprávy

- **Dotační dokumentace**
  - Žádost o dotaci
  - Energetický posudek
  - Technická dokumentace
  - Faktury a doklady`
    },
    {
      id: 'fve-samostatna',
      title: 'FVE - Samostatná instalace',
      type: 'lesson',
      content: `# FVE - Samostatná instalace

### Charakteristika produktu
- Samostatná fotovoltaická elektrárna
- Optimalizace pro vlastní spotřebu
- Bateriové úložiště
- Monitoring a řízení

### Procesní postup
1. **Přípravná fáze**
   - Analýza spotřeby
   - Technická prohlídka
   - Návrh řešení
   - Kalkulace návratnosti

2. **Projektová dokumentace**
   - Návrh FVE
   - Elektro projekt
   - Statický posudek
   - Požární bezpečnost

3. **Realizace**
   - Instalace konstrukce
   - Montáž panelů
   - Elektroinstalace
   - Připojení a zprovoznění

### Dokumenty a administrativa
- **Přípravná fáze**
  - Smlouva o dílo
  - Technická specifikace
  - Projektová dokumentace
  - Připojovací podmínky

- **Realizační fáze**
  - Revizní zprávy
  - Protokoly o instalaci
  - Dokumentace skutečného provedení
  - Předávací protokoly`
    },
    {
      id: 'prakticke-tipy',
      title: 'Praktické tipy pro obchodníky',
      type: 'lesson',
      content: `# Praktické tipy pro obchodníky

### Příprava na jednání
1. Prostudování specifik daného typu prodeje
2. Příprava referenčních projektů
3. Kalkulace a ekonomické podklady
4. Technické specifikace`
    }
  ]
}; 