import { Course } from '../types';
import InteractiveMindMap from '@/components/courses/InteractiveMindMap';

export const myslenkovaMapaObchodniProcesCourse: Course = {
  id: 'myslenkova-mapa-obchodni-proces',
  title: 'Myšlenková mapa obchodních procesů',
  description: 'Interaktivní přehled všech obchodních procesů a jejich vzájemných vazeb',
  duration: '30 minut',
  level: 'intermediate',
  tags: ['procesy', 'obchod', 'přehled'],
  modules: [
    {
      id: 'prehled',
      title: 'Přehled obchodních procesů',
      type: 'lesson',
      content: `# Přehled obchodních procesů AC Heating

## Interaktivní mapa procesů

Tato interaktivní mapa zobrazuje všechny klíčové obchodní procesy společnosti AC Heating. Kliknutím na jednotlivé položky se dostanete na detailní popis daného procesu.

<div class="my-8">
  <InteractiveMindMap />
</div>

## Hlavní kategorie procesů

### 1. Prodej Tepla
- Procesy pro developerské projekty
- Procesy pro SVJ a bytová družstva
- Licencování a administrativa

### 2. Fotovoltaika
- Samostatné FVE instalace
- Kombinované systémy s tepelnými čerpadly
- Dotační programy

### 3. Prodej Technologie
- Obchodní proces a jednání
- Technická realizace
- Kontrolní body

### 4. Společné procesy
- Dokumentace a administrativa
- Kontrolní mechanismy
- Povolení a licence`
    },
    {
      id: 'prace-s-procesy',
      title: 'Práce s procesy',
      type: 'lesson',
      content: `# Práce s procesy

## Základní principy

Každý proces v mapě má svůj specifický účel a návaznosti na ostatní procesy. Při práci s procesy je důležité:

1. Dodržovat stanovené postupy
2. Kontrolovat návaznosti mezi procesy
3. Dokumentovat všechny kroky
4. Komunikovat se všemi zainteresovanými stranami

## Propojení procesů

<div class="bg-content2 p-4 rounded-lg my-4">
  <h4 class="font-semibold text-default-700 dark:text-default-400">Důležité upozornění</h4>
  <p class="text-default-600 dark:text-default-300">
    Všechny procesy jsou vzájemně propojené a ovlivňují se. Je důležité vnímat tyto vazby a pracovat s nimi.
  </p>
</div>

### Příklady propojení:

1. **Prodej tepla + Fotovoltaika**
   - Kombinované řešení pro zákazníka
   - Společná technická příprava
   - Koordinace instalace

2. **Technologie + Společné procesy**
   - Dokumentace
   - Kontrolní body
   - Předávací protokoly

3. **Developer + SVJ/BD**
   - Podobné technické řešení
   - Rozdílný obchodní přístup
   - Specifické požadavky na dokumentaci`
    }
  ]
}; 