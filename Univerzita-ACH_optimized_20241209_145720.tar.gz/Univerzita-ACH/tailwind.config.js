const { nextui } = require("@nextui-org/react");

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    './node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}'
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eef2ff',
          100: '#e0e7ff',
          200: '#c7d2fe',
          300: '#a5b4fc',
          400: '#818cf8',
          500: '#004C97',
          600: '#0066CC',
          700: '#005CB8',
          800: '#0052A3',
          900: '#00478F',
          950: '#004085'
        }
      }
    }
  },
  plugins: [
    nextui({
      themes: {
        light: {
          colors: {
            background: "#ffffff",
            foreground: "#11181C",
            primary: {
              DEFAULT: "#004C97",
              foreground: "#ffffff"
            },
            focus: "#004C97",
            content1: {
              DEFAULT: "#ffffff",
              foreground: "#11181C"
            },
            content2: {
              DEFAULT: "#f8fafc",
              foreground: "#11181C"
            }
          }
        },
        dark: {
          colors: {
            background: "#0F172A",
            foreground: "#ECEDEE",
            primary: {
              DEFAULT: "#0066CC",
              foreground: "#ffffff"
            },
            focus: "#0066CC",
            content1: {
              DEFAULT: "#1E293B",
              foreground: "#ECEDEE"
            },
            content2: {
              DEFAULT: "#334155",
              foreground: "#ECEDEE"
            },
            content3: {
              DEFAULT: "#475569",
              foreground: "#ECEDEE"
            },
            content4: {
              DEFAULT: "#64748b",
              foreground: "#ECEDEE"
            },
            default: {
              100: "#ffffff",
              200: "#ECEDEE",
              300: "#D7D8DA",
              400: "#C3C4C7",
              500: "#AFB0B4",
              600: "#9B9CA1",
              700: "#87888E",
              800: "#73747B",
              900: "#5F6068",
              foreground: "#ECEDEE"
            }
          },
          layout: {
            hoverOpacity: 0.9,
            boxShadow: {
              small: "0px 0px 5px rgba(0, 0, 0, 0.05)",
              medium: "0px 0px 15px rgba(0, 0, 0, 0.1)",
              large: "0px 0px 30px rgba(0, 0, 0, 0.15)"
            }
          }
        }
      }
    }),
    require("tailwindcss-animate"),
    require('@tailwindcss/typography'),
  ]
};

